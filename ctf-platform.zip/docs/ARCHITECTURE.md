# System Architecture

## Overview

```mermaid
graph TB
    subgraph "Client Layer"
        A[React Frontend<br/>Vite + Tailwind]
    end

    subgraph "API Gateway"
        B[Nginx Reverse Proxy<br/>SSL/TLS Termination]
    end

    subgraph "Application Layer"
        C[Express.js API<br/>Node.js 18]
        D[Rate Limiter<br/>Redis]
    end

    subgraph "Data Layer"
        E[(MongoDB<br/>Primary DB)]
        F[(Redis<br/>Cache & Sessions)]
        G[File Storage<br/>Uploads]
    end

    subgraph "Challenge Infrastructure"
        H[Docker Labs<br/>Isolated Containers]
        I[Challenge Files<br/>PCAP, Binaries]
    end

    A -->|HTTPS| B
    B -->|Proxy| C
    C --> D
    C --> E
    C --> F
    C --> G
    C -->|Spawn| H
    C -->|Serve| I
```

## Authentication Flow

```mermaid
sequenceDiagram
    participant U as User
    participant F as Frontend
    participant A as API
    participant R as Redis
    participant M as MongoDB

    U->>F: Login Request
    F->>A: POST /api/auth/login
    A->>M: Validate Credentials
    M-->>A: User Data
    A->>A: Generate JWT + Refresh
    A->>R: Store Refresh Token
    A-->>F: Tokens + User Data
    F->>F: Store in localStorage
    F-->>U: Authenticated

    Note over U,F: Subsequent Requests
    F->>A: API Call + Bearer Token
    A->>A: Verify JWT
    A-->>F: Protected Data
```

## Challenge Submission Flow

```mermaid
sequenceDiagram
    participant U as User
    participant F as Frontend
    participant A as API
    participant R as Redis
    participant M as MongoDB

    U->>F: Submit Flag
    F->>A: POST /api/challenges/:id/submit
    A->>R: Check Rate Limit
    A->>M: Get Challenge (with flag)
    A->>A: Validate Flag
    A->>M: Record Submission
    A->>M: Update User Stats
    A->>M: Update Challenge Stats
    A->>R: Invalidate Cache
    A-->>F: Result + Points
    F-->>U: Success/Failure
```

## Security Layers

```
┌─────────────────────────────────────────┐
│           WAF / CDN (Optional)           │
├─────────────────────────────────────────┤
│         Nginx Reverse Proxy              │
│    - SSL/TLS Termination                 │
│    - Rate Limiting                       │
│    - Static File Serving                 │
├─────────────────────────────────────────┤
│         Express.js Application           │
│    - Helmet Security Headers             │
│    - CORS Configuration                  │
│    - Input Sanitization                  │
│    - JWT Authentication                  │
│    - Role-based Authorization            │
├─────────────────────────────────────────┤
│         Data Layer                       │
│    - MongoDB (Encrypted)                 │
│    - Redis (Session Store)               │
│    - File Storage (Isolated)             │
└─────────────────────────────────────────┘
```

## Deployment Architecture

```mermaid
graph TB
    subgraph "Production Environment"
        subgraph "Load Balancer"
            LB[AWS ALB / Nginx]
        end

        subgraph "Application Servers"
            API1[API Instance 1]
            API2[API Instance 2]
            API3[API Instance 3]
        end

        subgraph "Database Cluster"
            M1[MongoDB Primary]
            M2[MongoDB Secondary]
            M3[MongoDB Arbiter]
        end

        subgraph "Cache Layer"
            R1[Redis Primary]
            R2[Redis Replica]
        end

        subgraph "Storage"
            S3[S3 / EFS<br/>File Storage]
        end

        subgraph "Challenge Labs"
            D1[Docker Host 1]
            D2[Docker Host 2]
        end
    end

    LB --> API1
    LB --> API2
    LB --> API3
    API1 --> M1
    API2 --> M1
    API3 --> M1
    API1 --> R1
    API2 --> R1
    API3 --> R1
    API1 --> S3
    API2 --> S3
    API3 --> S3
    API1 --> D1
    API2 --> D2
```

## Data Flow

### User Registration
1. Client submits registration form
2. Frontend validates input (client-side)
3. API receives request
4. express-validator validates (server-side)
5. Check for existing user (email/username)
6. Hash password with bcrypt (12 rounds)
7. Generate verification token
8. Save user to MongoDB
9. Send verification email
10. Return JWT tokens

### Challenge Solve
1. User submits flag
2. Rate limit check (Redis)
3. Verify JWT token
4. Check if already solved
5. Check attempt limits
6. Compare flag (case-sensitive option)
7. Calculate points (dynamic scoring)
8. Update challenge stats
9. Update user stats & skill level
10. Award badges if criteria met
11. Create notification
12. Return result

## Technology Stack

### Frontend
- **Framework**: React 18 with Hooks
- **Build Tool**: Vite
- **Styling**: Tailwind CSS
- **Animation**: Framer Motion
- **State Management**: React Query + Zustand
- **Charts**: Recharts
- **Icons**: Lucide React

### Backend
- **Runtime**: Node.js 18 LTS
- **Framework**: Express.js 4
- **Database**: MongoDB 7.0 with Mongoose
- **Cache**: Redis 7
- **Authentication**: JWT (jsonwebtoken)
- **Validation**: express-validator
- **Security**: Helmet, CORS, Rate Limiting
- **Uploads**: Multer
- **Logging**: Winston

### Infrastructure
- **Containerization**: Docker + Docker Compose
- **Web Server**: Nginx
- **Process Management**: PM2 (production)
- **Monitoring**: Health checks + optional Sentry
- **CI/CD**: GitHub Actions (recommended)

## Scaling Considerations

### Horizontal Scaling
- Stateless API design allows multiple instances
- Redis for shared session storage
- MongoDB replica set for read scaling
- Nginx load balancing

### Performance Optimization
- Redis caching for challenge lists
- CDN for static assets
- Database indexing on frequently queried fields
- Connection pooling
- Compression (gzip/brotli)

### Security Hardening
- Non-root Docker containers
- Read-only file systems where possible
- Network segmentation
- Secrets management (AWS Secrets Manager / Vault)
- Regular security scanning (Snyk, Trivy)
- Automated dependency updates

## Monitoring & Observability

### Health Checks
- `/health` - Application health
- `/health/db` - Database connectivity
- `/health/redis` - Redis connectivity

### Logging
- Structured JSON logging with Winston
- Request/response logging
- Error tracking with Sentry
- Audit logging for security events

### Metrics (Recommended)
- Response times
- Error rates
- Active users
- Challenge solve rates
- Flag submission attempts
