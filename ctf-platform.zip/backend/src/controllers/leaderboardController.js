const { Leaderboard, User, Submission } = require('../models');
const logger = require('../utils/logger');

// @desc    Get global leaderboard
// @route   GET /api/leaderboard
// @access  Public
exports.getLeaderboard = async (req, res) => {
  try {
    const { page = 1, limit = 50, period = 'all' } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    let query = { isActive: true };
    let sortField = 'stats.totalPoints';

    if (period === 'weekly') {
      const weekStart = new Date();
      weekStart.setDate(weekStart.getDate() - weekStart.getDay());
      weekStart.setHours(0, 0, 0, 0);

      // Aggregate weekly stats
      const weeklyStats = await Submission.aggregate([
        {
          $match: {
            isCorrect: true,
            createdAt: { $gte: weekStart }
          }
        },
        {
          $group: {
            _id: '$user',
            points: { $sum: '$pointsEarned' },
            solves: { $sum: 1 }
          }
        },
        { $sort: { points: -1 } },
        { $skip: skip },
        { $limit: parseInt(limit) }
      ]);

      const userIds = weeklyStats.map(s => s._id);
      const users = await User.find({ _id: { $in: userIds } })
        .select('username profile.displayName profile.avatar stats');

      const userMap = new Map(users.map(u => [u._id.toString(), u]));

      const entries = weeklyStats.map((stat, index) => ({
        rank: skip + index + 1,
        user: userMap.get(stat._id.toString()),
        points: stat.points,
        challengesSolved: stat.solves
      }));

      return res.json({
        success: true,
        data: entries,
        period: 'weekly',
        weekStart
      });
    }

    // Global leaderboard
    const users = await User.find(query)
      .select('username profile.displayName profile.avatar stats skillLevel')
      .sort({ 'stats.totalPoints': -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const entries = users.map((user, index) => ({
      rank: skip + index + 1,
      user: {
        id: user._id,
        username: user.username,
        displayName: user.profile?.displayName,
        avatar: user.profile?.avatar
      },
      points: user.stats.totalPoints,
      challengesSolved: user.stats.challengesSolved,
      skillLevel: user.skillLevel,
      accuracy: user.stats.accuracy
    }));

    res.json({
      success: true,
      data: entries,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit)
      }
    });
  } catch (error) {
    logger.error('Get leaderboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch leaderboard'
    });
  }
};

// @desc    Get user rank
// @route   GET /api/leaderboard/rank
// @access  Private
exports.getUserRank = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    const higherRanked = await User.countDocuments({
      'stats.totalPoints': { $gt: user.stats.totalPoints }
    });

    res.json({
      success: true,
      data: {
        rank: higherRanked + 1,
        totalPoints: user.stats.totalPoints,
        challengesSolved: user.stats.challengesSolved
      }
    });
  } catch (error) {
    logger.error('Get user rank error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get rank'
    });
  }
};

// @desc    Get category leaderboard
// @route   GET /api/leaderboard/category/:category
// @access  Public
exports.getCategoryLeaderboard = async (req, res) => {
  try {
    const { category } = req.params;

    const stats = await Submission.aggregate([
      {
        $lookup: {
          from: 'challenges',
          localField: 'challenge',
          foreignField: '_id',
          as: 'challengeData'
        }
      },
      { $unwind: '$challengeData' },
      {
        $match: {
          'challengeData.category': category,
          isCorrect: true
        }
      },
      {
        $group: {
          _id: '$user',
          points: { $sum: '$pointsEarned' },
          solves: { $sum: 1 }
        }
      },
      { $sort: { points: -1 } },
      { $limit: 50 }
    ]);

    const userIds = stats.map(s => s._id);
    const users = await User.find({ _id: { $in: userIds } })
      .select('username profile.displayName profile.avatar');

    const userMap = new Map(users.map(u => [u._id.toString(), u]));

    const entries = stats.map((stat, index) => ({
      rank: index + 1,
      user: userMap.get(stat._id.toString()),
      points: stat.points,
      solves: stat.solves
    }));

    res.json({
      success: true,
      data: entries
    });
  } catch (error) {
    logger.error('Get category leaderboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch category leaderboard'
    });
  }
};
