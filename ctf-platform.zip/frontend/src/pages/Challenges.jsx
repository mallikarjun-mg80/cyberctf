import React, { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import axios from 'axios';
import { 
  Search, 
  Filter, 
  Lock, 
  Unlock, 
  Trophy, 
  Clock, 
  ChevronDown,
  Terminal,
  Globe,
  Shield,
  Lock as LockIcon,
  Cpu,
  FileSearch,
  Wifi,
  Target,
  Zap
} from 'lucide-react';
import { Link } from 'react-router-dom';

const categoryIcons = {
  'Networking': Globe,
  'Web Security': Shield,
  'Cryptography': LockIcon,
  'Binary Exploitation': Cpu,
  'Digital Forensics': FileSearch,
  'Malware Analysis': Target,
  'Wireless Security': Wifi,
  'Cloud Security': Cloud,
  'System Security': Terminal,
  'Network Attacks': Zap,
  'Reconnaissance': Search,
  'Modern Topics': Target,
  'Programming': Terminal,
  'Miscellaneous': Zap
};

const difficultyColors = {
  'Easy': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  'Medium': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  'Hard': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  'Insane': 'bg-red-500/20 text-red-400 border-red-500/30'
};

const Challenges = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || '');
  const [selectedDifficulty, setSelectedDifficulty] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['challenges', selectedCategory, selectedDifficulty, search],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedCategory) params.append('category', selectedCategory);
      if (selectedDifficulty) params.append('difficulty', selectedDifficulty);
      if (search) params.append('search', search);

      const response = await axios.get(`/api/challenges?${params}`);
      return response.data;
    }
  });

  const { data: categoriesData } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const response = await axios.get('/api/challenges/categories');
      return response.data;
    }
  });

  const challenges = data?.data || [];
  const categories = categoriesData?.data || [];

  const difficulties = ['Easy', 'Medium', 'Hard', 'Insane'];

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Challenges
          </h1>
          <p className="text-slate-400">
            Test your skills across {categories.length} categories and {challenges.length}+ challenges
          </p>
        </div>

        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <input
                type="text"
                placeholder="Search challenges..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 px-4 py-3 bg-slate-900 border border-slate-800 rounded-xl text-slate-300 hover:text-white hover:border-slate-700 transition-all"
            >
              <Filter className="w-5 h-5" />
              <span>Filters</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
            </button>
          </div>

          <AnimatePresence>
            {showFilters && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl space-y-4">
                  {/* Category Filter */}
                  <div>
                    <label className="text-sm font-medium text-slate-400 mb-2 block">Category</label>
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => setSelectedCategory('')}
                        className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                          !selectedCategory 
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                            : 'bg-slate-800 text-slate-400 border border-slate-700 hover:text-white'
                        }`}
                      >
                        All
                      </button>
                      {categories.map((cat) => (
                        <button
                          key={cat.category}
                          onClick={() => setSelectedCategory(cat.category)}
                          className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                            selectedCategory === cat.category
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-slate-800 text-slate-400 border border-slate-700 hover:text-white'
                          }`}
                        >
                          {cat.category}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Difficulty Filter */}
                  <div>
                    <label className="text-sm font-medium text-slate-400 mb-2 block">Difficulty</label>
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => setSelectedDifficulty('')}
                        className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                          !selectedDifficulty
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-slate-800 text-slate-400 border border-slate-700 hover:text-white'
                        }`}
                      >
                        All
                      </button>
                      {difficulties.map((diff) => (
                        <button
                          key={diff}
                          onClick={() => setSelectedDifficulty(diff)}
                          className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                            selectedDifficulty === diff
                              ? difficultyColors[diff]
                              : 'bg-slate-800 text-slate-400 border border-slate-700 hover:text-white'
                          }`}
                        >
                          {diff}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Challenges Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-400" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {challenges.map((challenge) => {
                const CategoryIcon = categoryIcons[challenge.category] || Terminal;
                return (
                  <motion.div
                    key={challenge._id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                  >
                    <Link
                      to={`/challenges/${challenge._id}`}
                      className="block p-6 rounded-2xl bg-slate-900/50 border border-slate-800 hover:border-emerald-500/30 transition-all group h-full"
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div className={`p-2 rounded-lg bg-gradient-to-br from-slate-800 to-slate-700`}>
                          <CategoryIcon className="w-5 h-5 text-emerald-400" />
                        </div>
                        <div className="flex items-center gap-2">
                          {challenge.isSolved && (
                            <div className="p-1 rounded-full bg-emerald-500/20">
                              <Unlock className="w-4 h-4 text-emerald-400" />
                            </div>
                          )}
                          <span className={`px-2 py-1 rounded-full text-xs font-medium border ${difficultyColors[challenge.difficulty]}`}>
                            {challenge.difficulty}
                          </span>
                        </div>
                      </div>

                      <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-emerald-400 transition-colors">
                        {challenge.title}
                      </h3>
                      <p className="text-slate-400 text-sm mb-4 line-clamp-2">
                        {challenge.description}
                      </p>

                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-4">
                          <span className="flex items-center gap-1 text-slate-500">
                            <Trophy className="w-4 h-4" />
                            {challenge.points} pts
                          </span>
                          <span className="flex items-center gap-1 text-slate-500">
                            <Target className="w-4 h-4" />
                            {challenge.solveCount} solves
                          </span>
                        </div>
                        <span className="text-slate-600">
                          {challenge.challengeType}
                        </span>
                      </div>

                      {challenge.tags && (
                        <div className="flex flex-wrap gap-1 mt-3">
                          {challenge.tags.slice(0, 3).map((tag) => (
                            <span
                              key={tag}
                              className="px-2 py-0.5 text-xs bg-slate-800 text-slate-400 rounded-full"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}
                    </Link>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}

        {!isLoading && challenges.length === 0 && (
          <div className="text-center py-20">
            <Search className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No challenges found</h3>
            <p className="text-slate-400">Try adjusting your search or filters</p>
          </div>
        )}
      </div>
    </div>
  );
};

// Missing Cloud icon import fix
const Cloud = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>
  </svg>
);

export default Challenges;
