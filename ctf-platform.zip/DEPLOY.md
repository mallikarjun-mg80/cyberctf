# 🚀 Quick Deploy Guide

## Option 1: One-Click Deploy (Recommended)

### Requirements
- Ubuntu 22.04+ / Debian 11+ / CentOS 8+
- 2 CPU cores, 4GB RAM, 20GB storage minimum
- Root or sudo access

### Deploy in 3 Steps

```bash
# 1. Download and extract
cd /opt
wget <your-zip-url>/ctf-platform.zip
unzip ctf-platform.zip
cd ctf-platform

# 2. Run deploy script
chmod +x deploy.sh
sudo ./deploy.sh

# 3. Access your platform
# Frontend: http://YOUR_SERVER_IP
# API: http://YOUR_SERVER_IP:5000
```

## Option 2: Docker Compose (Manual)

```bash
# 1. Install Docker & Docker Compose
curl -fsSL https://get.docker.com | sh

# 2. Start services
docker-compose up -d

# 3. Seed database
docker-compose exec backend npm run seed

# 4. Access at http://localhost
```

## Option 3: Cloud Platforms

### Render.com (Free Tier)
1. Create account at [render.com](https://render.com)
2. Click "New +" → "Blueprint"
3. Connect your GitHub repo
4. Render will auto-detect `render.yaml`

### Railway.app
1. Create account at [railway.app](https://railway.app)
2. Click "New Project" → "Deploy from GitHub repo"
3. Add MongoDB and Redis plugins
4. Set environment variables

### AWS EC2
```bash
# Launch Ubuntu 22.04 instance
# SSH into instance
sudo apt update && sudo apt install -y docker.io docker-compose
# Follow Option 2 above
```

### DigitalOcean Droplet
```bash
# Create droplet with Docker image
# SSH into droplet
# Follow Option 2 above
```

## SSL Setup (Let's Encrypt)

```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d yourdomain.com

# Auto-renewal is configured automatically
```

## Update .env for Production

Edit `.env` file:
```env
FRONTEND_URL=https://yourdomain.com
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

## Troubleshooting

```bash
# View logs
docker-compose logs -f

# Restart services
docker-compose restart

# Reset everything (WARNING: deletes data)
docker-compose down -v
docker-compose up -d
```
