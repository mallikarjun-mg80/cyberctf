import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import axios from 'axios';
import { Trophy, Medal, Crown, TrendingUp, Users, ChevronLeft, ChevronRight } from 'lucide-react';

const Leaderboard = () => {
  const [period, setPeriod] = useState('all');
  const [page, setPage] = useState(1);

  const { data, isLoading } = useQuery({
    queryKey: ['leaderboard', period, page],
    queryFn: async () => {
      const response = await axios.get(`/api/leaderboard?period=${period}&page=${page}&limit=50`);
      return response.data;
    }
  });

  const entries = data?.data || [];

  const getRankIcon = (rank) => {
    if (rank === 1) return <Crown className="w-6 h-6 text-yellow-400" />;
    if (rank === 2) return <Medal className="w-6 h-6 text-slate-300" />;
    if (rank === 3) return <Medal className="w-6 h-6 text-amber-600" />;
    return <span className="text-slate-500 font-mono w-6 text-center">{rank}</span>;
  };

  const getRankStyle = (rank) => {
    if (rank === 1) return 'bg-yellow-500/10 border-yellow-500/30';
    if (rank === 2) return 'bg-slate-400/10 border-slate-400/30';
    if (rank === 3) return 'bg-amber-600/10 border-amber-600/30';
    return 'bg-slate-900/50 border-slate-800';
  };

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 p-3 rounded-2xl bg-yellow-500/10 mb-4">
            <Trophy className="w-8 h-8 text-yellow-400" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Leaderboard
          </h1>
          <p className="text-slate-400">
            Top hackers ranked by points earned
          </p>
        </motion.div>

        {/* Period Filter */}
        <div className="flex justify-center gap-2 mb-8">
          {[
            { value: 'all', label: 'All Time' },
            { value: 'weekly', label: 'This Week' },
            { value: 'monthly', label: 'This Month' }
          ].map((p) => (
            <button
              key={p.value}
              onClick={() => { setPeriod(p.value); setPage(1); }}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                period === p.value
                  ? 'bg-emerald-500 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Leaderboard Table */}
        <div className="space-y-3">
          {isLoading ? (
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-400" />
            </div>
          ) : (
            <>
              {entries.map((entry, index) => (
                <motion.div
                  key={entry.user?.id || index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.03 }}
                  className={`flex items-center gap-4 p-4 rounded-xl border transition-all hover:border-emerald-500/30 ${getRankStyle(entry.rank)}`}
                >
                  <div className="flex items-center justify-center w-10">
                    {getRankIcon(entry.rank)}
                  </div>

                  <div className="flex-1 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center text-white font-bold text-sm">
                      {entry.user?.username?.charAt(0).toUpperCase() || '?'}
                    </div>
                    <div>
                      <p className="text-white font-medium">
                        {entry.user?.username || 'Anonymous'}
                      </p>
                      <p className="text-slate-500 text-xs">
                        {entry.skillLevel || 'Beginner'}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className="text-emerald-400 font-bold">{entry.points} pts</p>
                    <p className="text-slate-500 text-xs">{entry.challengesSolved} solved</p>
                  </div>
                </motion.div>
              ))}

              {entries.length === 0 && (
                <div className="text-center py-20 text-slate-500">
                  <Users className="w-12 h-12 mx-auto mb-4" />
                  <p>No entries yet. Be the first!</p>
                </div>
              )}
            </>
          )}
        </div>

        {/* Pagination */}
        {entries.length > 0 && (
          <div className="flex items-center justify-center gap-4 mt-8">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <span className="text-slate-400">Page {page}</span>
            <button
              onClick={() => setPage(p => p + 1)}
              disabled={entries.length < 50}
              className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Leaderboard;
