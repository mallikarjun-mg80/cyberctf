const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const generateToken = (payload, type = 'access') => {
  const secret = type === 'access' 
    ? process.env.JWT_SECRET 
    : process.env.JWT_REFRESH_SECRET;
  const expiresIn = type === 'access' 
    ? process.env.JWT_EXPIRE || '7d'
    : process.env.JWT_REFRESH_EXPIRE || '30d';

  return jwt.sign(payload, secret, { expiresIn });
};

const verifyToken = (token, type = 'access') => {
  const secret = type === 'access' 
    ? process.env.JWT_SECRET 
    : process.env.JWT_REFRESH_SECRET;

  return jwt.verify(token, secret);
};

const generatePasswordResetToken = () => {
  const resetToken = crypto.randomBytes(32).toString('hex');
  const hashedToken = crypto
    .createHash('sha256')
    .update(resetToken)
    .digest('hex');

  return { resetToken, hashedToken };
};

const generateVerificationToken = () => {
  return crypto.randomBytes(32).toString('hex');
};

module.exports = {
  generateToken,
  verifyToken,
  generatePasswordResetToken,
  generateVerificationToken
};
