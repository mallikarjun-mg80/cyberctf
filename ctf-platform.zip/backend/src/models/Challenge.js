const mongoose = require('mongoose');

const challengeSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Challenge title is required'],
    trim: true,
    maxlength: [200, 'Title cannot exceed 200 characters']
  },
  slug: {
    type: String,
    unique: true,
    required: true
  },
  description: {
    type: String,
    required: [true, 'Description is required'],
    maxlength: [10000, 'Description too long']
  },
  category: {
    type: String,
    required: true,
    enum: [
      'Networking',
      'Reconnaissance',
      'Web Security',
      'Cryptography',
      'System Security',
      'Binary Exploitation',
      'Network Attacks',
      'Modern Topics',
      'Digital Forensics',
      'Malware Analysis',
      'Wireless Security',
      'Cloud Security',
      'Reverse Engineering',
      'Steganography',
      'OSINT',
      'Programming',
      'Miscellaneous'
    ]
  },
  subcategory: {
    type: String,
    required: true
  },
  difficulty: {
    type: String,
    required: true,
    enum: ['Easy', 'Medium', 'Hard', 'Insane']
  },
  points: {
    type: Number,
    required: true,
    min: 10,
    max: 1000
  },
  dynamicScoring: {
    enabled: { type: Boolean, default: false },
    initialPoints: Number,
    minPoints: Number,
    decay: Number, // points lost per solve
    solves: { type: Number, default: 0 }
  },
  flag: {
    type: String,
    required: [true, 'Flag is required'],
    select: false
  },
  flagFormat: {
    type: String,
    default: 'CTF{...}'
  },
  flagCaseSensitive: {
    type: Boolean,
    default: false
  },
  challengeType: {
    type: String,
    required: true,
    enum: ['quiz', 'flag', 'file_analysis', 'interactive_lab', 'real_world', 'code_review', 'multi_stage']
  },
  attachments: [{
    filename: String,
    originalName: String,
    mimeType: String,
    size: Number,
    path: String,
    description: String
  }],
  hints: [{
    content: String,
    cost: { type: Number, default: 0 }, // points deducted
    order: Number,
    isLocked: { type: Boolean, default: true }
  }],
  prerequisites: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Challenge'
  }],
  skills: [String], // Required skills
  learningObjectives: [String],
  resources: [{
    title: String,
    url: String,
    type: { type: String, enum: ['article', 'video', 'tool', 'documentation'] }
  }],
  writeup: {
    content: String,
    author: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    published: { type: Boolean, default: false },
    publishedAt: Date
  },
  quizQuestions: [{
    question: String,
    options: [String],
    correctAnswer: Number,
    explanation: String
  }],
  dockerConfig: {
    image: String,
    ports: [Number],
    environment: mongoose.Schema.Types.Mixed,
    memoryLimit: { type: String, default: '512m' },
    cpuLimit: { type: String, default: '1.0' },
    timeout: { type: Number, default: 300 } // seconds
  },
  isActive: { type: Boolean, default: true },
  isPremium: { type: Boolean, default: false },
  isTimeLimited: { type: Boolean, default: false },
  timeLimit: { type: Number, default: 0 }, // in minutes
  startTime: Date,
  endTime: Date,
  maxAttempts: { type: Number, default: 0 }, // 0 = unlimited
  solveCount: { type: Number, default: 0 },
  firstBlood: {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    solvedAt: Date
  },
  averageSolveTime: { type: Number, default: 0 }, // in minutes
  successRate: { type: Number, default: 0 },
  rating: {
    average: { type: Number, default: 0 },
    count: { type: Number, default: 0 }
  },
  tags: [String],
  author: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  verifiedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  isVerified: { type: Boolean, default: false }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes
challengeSchema.index({ category: 1, difficulty: 1 });
challengeSchema.index({ tags: 1 });
challengeSchema.index({ points: -1 });
challengeSchema.index({ isActive: 1, isVerified: 1 });
challengeSchema.index({ slug: 1 });

// Virtual for completion percentage
challengeSchema.virtual('completionRate').get(function() {
  // This would be calculated based on total users vs solves
  return this.successRate;
});

// Pre-save middleware for slug generation
challengeSchema.pre('save', function(next) {
  if (this.isModified('title') && !this.slug) {
    this.slug = this.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  }
  next();
});

// Method to calculate dynamic points
challengeSchema.methods.calculateDynamicPoints = function() {
  if (!this.dynamicScoring.enabled) return this.points;

  const { initialPoints, minPoints, decay, solves } = this.dynamicScoring;
  const calculated = Math.max(minPoints, initialPoints - (solves * decay));
  return Math.round(calculated);
};

module.exports = mongoose.model('Challenge', challengeSchema);
