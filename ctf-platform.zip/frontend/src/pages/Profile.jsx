import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import axios from 'axios';
import { Trophy, Target, Award, Calendar, MapPin, Link as LinkIcon, Github, Twitter } from 'lucide-react';

const Profile = () => {
  const { username } = useParams();

  const { data, isLoading } = useQuery({
    queryKey: ['profile', username],
    queryFn: async () => {
      const response = await axios.get(`/api/users/${username}`);
      return response.data;
    }
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-400" />
      </div>
    );
  }

  const profile = data?.data;

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Profile Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="p-8 rounded-2xl bg-slate-900/50 border border-slate-800">
            <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
              <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center text-white text-3xl font-bold">
                {profile?.username?.charAt(0).toUpperCase()}
              </div>

              <div className="flex-1 text-center md:text-left">
                <h1 className="text-2xl font-bold text-white mb-1">
                  {profile?.profile?.displayName || profile?.username}
                </h1>
                <p className="text-slate-400 mb-4">@{profile?.username}</p>

                {profile?.profile?.bio && (
                  <p className="text-slate-300 mb-4 max-w-lg">{profile.profile.bio}</p>
                )}

                <div className="flex flex-wrap items-center justify-center md:justify-start gap-4">
                  {profile?.profile?.country && (
                    <span className="flex items-center gap-1 text-slate-400 text-sm">
                      <MapPin className="w-4 h-4" />
                      {profile.profile.country}
                    </span>
                  )}
                  {profile?.profile?.website && (
                    <a href={profile.profile.website} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-emerald-400 text-sm hover:underline">
                      <LinkIcon className="w-4 h-4" />
                      Website
                    </a>
                  )}
                  {profile?.profile?.github && (
                    <a href={`https://github.com/${profile.profile.github}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-slate-400 text-sm hover:text-white">
                      <Github className="w-4 h-4" />
                      GitHub
                    </a>
                  )}
                </div>
              </div>

              <div className="flex flex-col items-center gap-2">
                <span className="px-4 py-2 bg-emerald-500/20 text-emerald-400 rounded-full text-sm font-medium">
                  {profile?.skillLevel}
                </span>
                <span className="text-slate-500 text-xs">
                  <Calendar className="w-3 h-3 inline mr-1" />
                  Joined {new Date(profile?.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { icon: Trophy, label: 'Points', value: profile?.stats?.totalPoints || 0 },
            { icon: Target, label: 'Solved', value: profile?.stats?.challengesSolved || 0 },
            { icon: Award, label: 'Accuracy', value: `${profile?.stats?.accuracy || 0}%` },
            { icon: Calendar, label: 'Streak', value: `${profile?.stats?.currentStreak || 0} days` },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 text-center"
            >
              <stat.icon className="w-5 h-5 text-emerald-400 mx-auto mb-2" />
              <div className="text-xl font-bold text-white">{stat.value}</div>
              <div className="text-slate-500 text-xs">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Badges */}
        {profile?.badges && profile.badges.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mb-8"
          >
            <h2 className="text-xl font-semibold text-white mb-4">Badges</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {profile.badges.map((badge, index) => (
                <div
                  key={index}
                  className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 text-center"
                >
                  <div 
                    className="w-12 h-12 rounded-full mx-auto mb-2 flex items-center justify-center"
                    style={{ backgroundColor: `${badge.badge?.color}20` }}
                  >
                    <Award className="w-6 h-6" style={{ color: badge.badge?.color }} />
                  </div>
                  <p className="text-white text-sm font-medium">{badge.badge?.name}</p>
                  <p className="text-slate-500 text-xs">{badge.badge?.rarity}</p>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Completed Challenges */}
        {profile?.completedChallenges && profile.completedChallenges.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <h2 className="text-xl font-semibold text-white mb-4">Completed Challenges</h2>
            <div className="space-y-2">
              {profile.completedChallenges.slice(0, 20).map((completed, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 rounded-xl bg-slate-900/50 border border-slate-800"
                >
                  <div>
                    <p className="text-white text-sm font-medium">
                      {completed.challenge?.title || 'Unknown Challenge'}
                    </p>
                    <p className="text-slate-500 text-xs">
                      {completed.challenge?.category} • {completed.challenge?.difficulty}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-emerald-400 text-sm font-medium">+{completed.pointsEarned} pts</p>
                    <p className="text-slate-500 text-xs">
                      {new Date(completed.completedAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Profile;
