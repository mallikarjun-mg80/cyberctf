const User = require('./User');
const Challenge = require('./Challenge');
const Submission = require('./Submission');
const Badge = require('./Badge');
const Leaderboard = require('./Leaderboard');
const Team = require('./Team');
const Event = require('./Event');
const Writeup = require('./Writeup');
const Notification = require('./Notification');
const Progress = require('./Progress');

module.exports = {
  User,
  Challenge,
  Submission,
  Badge,
  Leaderboard,
  Team,
  Event,
  Writeup,
  Notification,
  Progress
};
