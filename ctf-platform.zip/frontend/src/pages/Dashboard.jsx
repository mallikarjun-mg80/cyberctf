import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';
import { 
  Trophy, 
  Target, 
  Flame, 
  TrendingUp, 
  Award,
  Clock,
  CheckCircle,
  XCircle,
  Zap,
  Activity,
  Shield,
  ChevronRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

const Dashboard = () => {
  const { user } = useAuth();

  const { data, isLoading } = useQuery({
    queryKey: ['dashboard'],
    queryFn: async () => {
      const response = await axios.get('/api/users/dashboard');
      return response.data;
    }
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-400" />
      </div>
    );
  }

  const { 
    user: userData, 
    recentSubmissions, 
    categoryProgress, 
    skillData, 
    activityData 
  } = data?.data || {};

  const radarData = skillData?.map(skill => ({
    subject: skill._id,
    A: Math.min(skill.count * 20, 100),
    fullMark: 100
  })) || [];

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Welcome back, <span className="text-emerald-400">{user?.username}</span>!
          </h1>
          <p className="text-slate-400">
            Here's your progress overview and recent activity.
          </p>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { icon: Trophy, label: 'Total Points', value: userData?.stats?.totalPoints || 0, color: 'text-yellow-400', bg: 'bg-yellow-500/10' },
            { icon: Target, label: 'Solved', value: userData?.stats?.challengesSolved || 0, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
            { icon: Flame, label: 'Streak', value: `${userData?.streak?.current || 0} days`, color: 'text-orange-400', bg: 'bg-orange-500/10' },
            { icon: Zap, label: 'Accuracy', value: `${userData?.stats?.accuracy || 0}%`, color: 'text-blue-400', bg: 'bg-blue-500/10' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800"
            >
              <div className={`inline-flex p-2 rounded-lg ${stat.bg} ${stat.color} mb-3`}>
                <stat.icon className="w-5 h-5" />
              </div>
              <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
              <div className="text-slate-500 text-sm">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Activity Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2 p-6 rounded-2xl bg-slate-900/50 border border-slate-800"
          >
            <h2 className="text-xl font-semibold text-white mb-6">Activity (Last 30 Days)</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={activityData || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="_id" stroke="#64748b" fontSize={12} />
                  <YAxis stroke="#64748b" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1e293b', 
                      border: '1px solid #334155',
                      borderRadius: '8px',
                      color: '#f1f5f9'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="count" 
                    stroke="#10b981" 
                    strokeWidth={2}
                    dot={{ fill: '#10b981', strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* Skill Radar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800"
          >
            <h2 className="text-xl font-semibold text-white mb-6">Skills</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData}>
                  <PolarGrid stroke="#334155" />
                  <PolarAngleAxis dataKey="subject" stroke="#64748b" fontSize={10} />
                  <PolarRadiusAxis stroke="#64748b" fontSize={10} />
                  <Radar
                    name="Skills"
                    dataKey="A"
                    stroke="#10b981"
                    fill="#10b981"
                    fillOpacity={0.3}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        </div>

        {/* Category Progress */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-8 p-6 rounded-2xl bg-slate-900/50 border border-slate-800"
        >
          <h2 className="text-xl font-semibold text-white mb-6">Category Progress</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {categoryProgress?.map((cat) => (
              <div key={cat._id} className="p-4 rounded-xl bg-slate-800/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-medium">{cat._id}</span>
                  <span className="text-emerald-400 text-sm">{cat.solved} solved</span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2 mb-2">
                  <div 
                    className="bg-emerald-500 h-2 rounded-full transition-all"
                    style={{ width: `${Math.min((cat.solved / 10) * 100, 100)}%` }}
                  />
                </div>
                <div className="text-slate-500 text-xs">{cat.points} points earned</div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Recent Submissions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-8 p-6 rounded-2xl bg-slate-900/50 border border-slate-800"
        >
          <h2 className="text-xl font-semibold text-white mb-6">Recent Submissions</h2>
          <div className="space-y-3">
            {recentSubmissions?.slice(0, 10).map((sub, index) => (
              <div 
                key={index}
                className="flex items-center justify-between p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors"
              >
                <div className="flex items-center gap-3">
                  {sub.isCorrect ? (
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <XCircle className="w-5 h-5 text-red-400" />
                  )}
                  <div>
                    <p className="text-white text-sm font-medium">
                      {sub.challenge?.title || 'Unknown Challenge'}
                    </p>
                    <p className="text-slate-500 text-xs">
                      {sub.challenge?.category} • {sub.challenge?.difficulty}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-slate-400 text-xs">
                    {new Date(sub.createdAt).toLocaleDateString()}
                  </p>
                  {sub.isCorrect && (
                    <p className="text-emerald-400 text-xs">+{sub.pointsEarned} pts</p>
                  )}
                </div>
              </div>
            ))}
            {(!recentSubmissions || recentSubmissions.length === 0) && (
              <div className="text-center py-8 text-slate-500">
                No submissions yet. Start solving challenges!
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;
