const mongoose = require('mongoose');
const { Challenge, Badge, User } = require('../models');
const logger = require('./logger');

const challenges = [
  // === NETWORKING (Foundation) ===
  {
    title: 'OSI Model Mastery',
    slug: 'osi-model-mastery',
    description: 'Test your knowledge of the 7 layers of the OSI model. Identify which layer handles specific networking functions.',
    category: 'Networking',
    subcategory: 'OSI Model',
    difficulty: 'Easy',
    points: 50,
    challengeType: 'quiz',
    flag: 'CTF{osi_layer_7_application}',
    flagFormat: 'CTF{...}',
    tags: ['networking', 'osi', 'fundamentals'],
    quizQuestions: [
      { question: 'Which OSI layer is responsible for routing?', options: ['Transport', 'Network', 'Data Link', 'Session'], correctAnswer: 1, explanation: 'Layer 3 (Network) handles routing and logical addressing.' }
    ],
    learningObjectives: ['Understand OSI model layers', 'Identify layer functions'],
    resources: [
      { title: 'OSI Model Guide', url: 'https://example.com/osi', type: 'article' }
    ]
  },
  {
    title: 'TCP Handshake Analysis',
    slug: 'tcp-handshake-analysis',
    description: 'Analyze a PCAP file to identify the 3-way TCP handshake between two hosts. Find the sequence numbers.',
    category: 'Networking',
    subcategory: 'TCP/IP',
    difficulty: 'Easy',
    points: 75,
    challengeType: 'file_analysis',
    flag: 'CTF{syn_ack_seq_12345}',
    tags: ['tcp', 'pcap', 'wireshark', 'networking'],
    attachments: [{ filename: 'handshake.pcap', description: 'Network capture file' }],
    learningObjectives: ['Understand TCP 3-way handshake', 'Analyze network traffic']
  },
  {
    title: 'Subnetting Challenge',
    slug: 'subnetting-challenge',
    description: 'Given the IP 192.168.1.0/26, determine the number of usable hosts, broadcast address, and network address.',
    category: 'Networking',
    subcategory: 'IP Addressing',
    difficulty: 'Medium',
    points: 100,
    challengeType: 'flag',
    flag: 'CTF{62_hosts_192.168.1.63}',
    tags: ['subnetting', 'ipv4', 'networking'],
    learningObjectives: ['Calculate subnet masks', 'Determine host ranges']
  },
  {
    title: 'DNS Enumeration Basics',
    slug: 'dns-enumeration-basics',
    description: 'Use dig and nslookup to find hidden subdomains of target.com. One subdomain contains the flag.',
    category: 'Networking',
    subcategory: 'DNS',
    difficulty: 'Easy',
    points: 60,
    challengeType: 'interactive_lab',
    flag: 'CTF{secret.subdomain.target.com}',
    tags: ['dns', 'enumeration', 'reconnaissance'],
    learningObjectives: ['Perform DNS enumeration', 'Use dig and nslookup']
  },
  {
    title: 'DHCP Starvation',
    slug: 'dhcp-starvation',
    description: 'Understand how DHCP starvation attacks work. Analyze the provided network log to identify the attack vector.',
    category: 'Networking',
    subcategory: 'DHCP',
    difficulty: 'Hard',
    points: 200,
    challengeType: 'file_analysis',
    flag: 'CTF{dhcp_chaddr_spoofing}',
    tags: ['dhcp', 'network-attacks', 'forensics'],
    learningObjectives: ['Understand DHCP protocol', 'Identify DHCP attacks']
  },
  {
    title: 'NAT Traversal',
    slug: 'nat-traversal',
    description: 'Analyze a network diagram with NAT configuration. Identify the public IP mapping for internal host 10.0.0.5.',
    category: 'Networking',
    subcategory: 'NAT',
    difficulty: 'Medium',
    points: 125,
    challengeType: 'flag',
    flag: 'CTF{203.0.113.45}',
    tags: ['nat', 'networking', 'firewall'],
    learningObjectives: ['Understand NAT types', 'Analyze NAT tables']
  },
  {
    title: 'ARP Poisoning Detection',
    slug: 'arp-poisoning-detection',
    description: 'Analyze the provided PCAP to detect ARP poisoning attempts. Identify the attacker MAC address.',
    category: 'Networking',
    subcategory: 'ARP',
    difficulty: 'Medium',
    points: 150,
    challengeType: 'file_analysis',
    flag: 'CTF{aa:bb:cc:dd:ee:ff}',
    tags: ['arp', 'mitm', 'network-attacks', 'wireshark'],
    learningObjectives: ['Understand ARP protocol', 'Detect ARP spoofing']
  },
  {
    title: 'VLAN Hopping',
    slug: 'vlan-hopping',
    description: 'Exploit a switch misconfiguration to hop between VLANs. The flag is in VLAN 100.',
    category: 'Networking',
    subcategory: 'VLANs',
    difficulty: 'Hard',
    points: 250,
    challengeType: 'interactive_lab',
    flag: 'CTF{double_tagging_exploit}',
    tags: ['vlan', 'switching', 'network-attacks'],
    learningObjectives: ['Understand VLAN security', 'Exploit VLAN hopping']
  },
  {
    title: 'VPN Tunnel Analysis',
    slug: 'vpn-tunnel-analysis',
    description: 'Decrypt the provided VPN capture using the given pre-shared key. Extract the hidden flag.',
    category: 'Networking',
    subcategory: 'VPN',
    difficulty: 'Insane',
    points: 400,
    challengeType: 'file_analysis',
    flag: 'CTF{ipsec_tunnel_decrypted}',
    tags: ['vpn', 'ipsec', 'cryptography', 'forensics'],
    learningObjectives: ['Understand VPN protocols', 'Decrypt VPN traffic']
  },
  {
    title: 'Firewall Rules Analysis',
    slug: 'firewall-rules-analysis',
    description: 'Analyze the iptables rules to determine which ports are open. Find the backdoor port.',
    category: 'Networking',
    subcategory: 'Firewalls',
    difficulty: 'Medium',
    points: 130,
    challengeType: 'flag',
    flag: 'CTF{port_31337_backdoor}',
    tags: ['firewall', 'iptables', 'network-security'],
    learningObjectives: ['Read firewall rules', 'Identify misconfigurations']
  },

  // === RECONNAISSANCE & OSINT ===
  {
    title: 'Footprinting 101',
    slug: 'footprinting-101',
    description: 'Gather information about target.com using passive reconnaissance techniques. Find the hidden API endpoint.',
    category: 'Reconnaissance',
    subcategory: 'Footprinting',
    difficulty: 'Easy',
    points: 50,
    challengeType: 'flag',
    flag: 'CTF{api.target.com/v1/secret}',
    tags: ['osint', 'reconnaissance', 'footprinting'],
    learningObjectives: ['Perform passive reconnaissance', 'Use OSINT tools']
  },
  {
    title: 'WHOIS Detective',
    slug: 'whois-detective',
    description: 'Use WHOIS lookup to find registration details. The flag is the registrant organization name.',
    category: 'Reconnaissance',
    subcategory: 'WHOIS',
    difficulty: 'Easy',
    points: 40,
    challengeType: 'flag',
    flag: 'CTF{CyberSecurity_Corp}',
    tags: ['whois', 'osint', 'reconnaissance'],
    learningObjectives: ['Perform WHOIS lookups', 'Extract domain information']
  },
  {
    title: 'Nmap Network Scan',
    slug: 'nmap-network-scan',
    description: 'Scan the target network 10.10.10.0/24. Identify the host running a web server on a non-standard port.',
    category: 'Reconnaissance',
    subcategory: 'Network Scanning',
    difficulty: 'Easy',
    points: 75,
    challengeType: 'interactive_lab',
    flag: 'CTF{10.10.10.15:8080}',
    tags: ['nmap', 'scanning', 'reconnaissance'],
    learningObjectives: ['Use Nmap effectively', 'Interpret scan results']
  },
  {
    title: 'Banner Grabbing',
    slug: 'banner-grabbing',
    description: 'Connect to the target service and grab the banner. The server version contains the flag.',
    category: 'Reconnaissance',
    subcategory: 'Banner Grabbing',
    difficulty: 'Easy',
    points: 60,
    challengeType: 'interactive_lab',
    flag: 'CTF{Apache_2.4.41_vulnerable}',
    tags: ['banner', 'reconnaissance', 'enumeration'],
    learningObjectives: ['Perform banner grabbing', 'Identify service versions']
  },
  {
    title: 'Social Engineering OSINT',
    slug: 'social-engineering-osint',
    description: 'Find the CEO email address from public sources. Use the format firstname.lastname@company.com.',
    category: 'Reconnaissance',
    subcategory: 'OSINT',
    difficulty: 'Medium',
    points: 100,
    challengeType: 'flag',
    flag: 'CTF{john.smith@cybercorp.com}',
    tags: ['osint', 'social-engineering', 'reconnaissance'],
    learningObjectives: ['Gather information from public sources', 'Understand social engineering']
  },

  // === WEB SECURITY ===
  {
    title: 'SQL Injection Basics',
    slug: 'sql-injection-basics',
    description: 'The login form is vulnerable to SQL injection. Bypass authentication to access the admin panel.',
    category: 'Web Security',
    subcategory: 'SQL Injection',
    difficulty: 'Easy',
    points: 100,
    challengeType: 'interactive_lab',
    flag: 'CTF{sql_injection_master}',
    tags: ['sql-injection', 'web', 'authentication'],
    learningObjectives: ['Understand SQL injection', 'Bypass authentication'],
    dockerConfig: {
      image: 'ctf-platform/sqli-lab',
      ports: [3000],
      environment: { FLAG: 'CTF{sql_injection_master}' }
    }
  },
  {
    title: 'Blind SQL Injection',
    slug: 'blind-sql-injection',
    description: 'Extract the admin password using boolean-based blind SQL injection. No error messages are shown.',
    category: 'Web Security',
    subcategory: 'SQL Injection',
    difficulty: 'Hard',
    points: 300,
    challengeType: 'interactive_lab',
    flag: 'CTF{blind_sql_extraction_complete}',
    tags: ['sql-injection', 'blind', 'web', 'advanced'],
    learningObjectives: ['Perform blind SQL injection', 'Use time-based techniques']
  },
  {
    title: 'Stored XSS',
    slug: 'stored-xss',
    description: 'The comment section stores user input without sanitization. Inject a payload to steal the admin cookie.',
    category: 'Web Security',
    subcategory: 'XSS',
    difficulty: 'Medium',
    points: 150,
    challengeType: 'interactive_lab',
    flag: 'CTF{stored_xss_admin_cookie_stolen}',
    tags: ['xss', 'stored', 'web', 'javascript'],
    learningObjectives: ['Understand stored XSS', 'Steal cookies via XSS']
  },
  {
    title: 'Reflected XSS',
    slug: 'reflected-xss',
    description: 'The search parameter reflects user input. Craft a URL that executes JavaScript when clicked.',
    category: 'Web Security',
    subcategory: 'XSS',
    difficulty: 'Easy',
    points: 100,
    challengeType: 'interactive_lab',
    flag: 'CTF{reflected_xss_triggered}',
    tags: ['xss', 'reflected', 'web'],
    learningObjectives: ['Understand reflected XSS', 'Craft malicious URLs']
  },
  {
    title: 'DOM-based XSS',
    slug: 'dom-based-xss',
    description: 'The application uses JavaScript to update the DOM based on URL fragments. Exploit this to execute code.',
    category: 'Web Security',
    subcategory: 'XSS',
    difficulty: 'Hard',
    points: 250,
    challengeType: 'interactive_lab',
    flag: 'CTF{dom_xss_source_sink}',
    tags: ['xss', 'dom', 'javascript', 'web'],
    learningObjectives: ['Understand DOM XSS', 'Identify sources and sinks']
  },
  {
    title: 'CSRF Attack',
    slug: 'csrf-attack',
    description: 'The bank transfer form lacks CSRF protection. Create a malicious HTML page that transfers funds.',
    category: 'Web Security',
    subcategory: 'CSRF',
    difficulty: 'Medium',
    points: 150,
    challengeType: 'interactive_lab',
    flag: 'CTF{csrf_token_missing}',
    tags: ['csrf', 'web', 'session'],
    learningObjectives: ['Understand CSRF attacks', 'Bypass CSRF protection']
  },
  {
    title: 'File Upload Bypass',
    slug: 'file-upload-bypass',
    description: 'Upload a PHP shell by bypassing the file type validation. The server only checks extensions.',
    category: 'Web Security',
    subcategory: 'File Upload',
    difficulty: 'Medium',
    points: 175,
    challengeType: 'interactive_lab',
    flag: 'CTF{shell_uploaded_rce_achieved}',
    tags: ['file-upload', 'rce', 'web', 'bypass'],
    learningObjectives: ['Bypass file upload restrictions', 'Achieve RCE']
  },
  {
    title: 'Authentication Bypass',
    slug: 'authentication-bypass',
    description: 'The JWT implementation uses the algorithm none. Forge a token to access the admin dashboard.',
    category: 'Web Security',
    subcategory: 'Authentication',
    difficulty: 'Hard',
    points: 275,
    challengeType: 'interactive_lab',
    flag: 'CTF{jwt_alg_none_vulnerability}',
    tags: ['jwt', 'authentication', 'bypass', 'web'],
    learningObjectives: ['Understand JWT vulnerabilities', 'Forge tokens']
  },
  {
    title: 'Session Hijacking',
    slug: 'session-hijacking',
    description: 'Capture the session cookie from unencrypted HTTP traffic. Use it to impersonate the victim.',
    category: 'Web Security',
    subcategory: 'Session Management',
    difficulty: 'Medium',
    points: 150,
    challengeType: 'interactive_lab',
    flag: 'CTF{session_cookie_hijacked}',
    tags: ['session', 'hijacking', 'mitm', 'web'],
    learningObjectives: ['Understand session management', 'Hijack sessions']
  },
  {
    title: 'OWASP Top 10 - Broken Access Control',
    slug: 'owasp-broken-access-control',
    description: 'Access another users account by manipulating the user ID parameter. IDOR vulnerability present.',
    category: 'Web Security',
    subcategory: 'OWASP Top 10',
    difficulty: 'Easy',
    points: 100,
    challengeType: 'interactive_lab',
    flag: 'CTF{idor_vulnerability_found}',
    tags: ['owasp', 'idor', 'access-control', 'web'],
    learningObjectives: ['Understand IDOR', 'Test for broken access control']
  },
  {
    title: 'OWASP Top 10 - Security Misconfiguration',
    slug: 'owasp-security-misconfiguration',
    description: 'Find the exposed .env file and database credentials. The flag is the database password.',
    category: 'Web Security',
    subcategory: 'OWASP Top 10',
    difficulty: 'Easy',
    points: 75,
    challengeType: 'interactive_lab',
    flag: 'CTF{db_password_exposed_123}',
    tags: ['owasp', 'misconfiguration', 'web'],
    learningObjectives: ['Identify security misconfigurations', 'Find exposed files']
  },
  {
    title: 'OWASP Top 10 - Vulnerable Components',
    slug: 'owasp-vulnerable-components',
    description: 'The application uses a vulnerable version of Log4j. Exploit CVE-2021-44228 to get RCE.',
    category: 'Web Security',
    subcategory: 'OWASP Top 10',
    difficulty: 'Hard',
    points: 350,
    challengeType: 'interactive_lab',
    flag: 'CTF{log4j_rce_cve_2021_44228}',
    tags: ['owasp', 'log4j', 'rce', 'cve'],
    learningObjectives: ['Understand Log4Shell', 'Exploit vulnerable components']
  },

  // === CRYPTOGRAPHY ===
  {
    title: 'Caesar Cipher',
    slug: 'caesar-cipher',
    description: 'Decrypt the message: ZHOFRPH WR FWBHU VHFXULWB',
    category: 'Cryptography',
    subcategory: 'Classical Ciphers',
    difficulty: 'Easy',
    points: 25,
    challengeType: 'flag',
    flag: 'CTF{caesar_shift_3}',
    tags: ['cryptography', 'caesar', 'classical'],
    learningObjectives: ['Understand substitution ciphers', 'Perform Caesar decryption']
  },
  {
    title: 'Base64 Decoding',
    slug: 'base64-decoding',
    description: 'Decode: Q1RGe2Jhc2U2NF9kZWNvZGluZ19tYXN0ZXJ9',
    category: 'Cryptography',
    subcategory: 'Encoding',
    difficulty: 'Easy',
    points: 30,
    challengeType: 'flag',
    flag: 'CTF{base64_decoding_master}',
    tags: ['cryptography', 'base64', 'encoding'],
    learningObjectives: ['Decode Base64', 'Understand encoding schemes']
  },
  {
    title: 'XOR Encryption',
    slug: 'xor-encryption',
    description: 'The flag was XOR encrypted with key 0x42. Decrypt the hex: 8b9e8d8a9f9c9b9e8d8a9f9c',
    category: 'Cryptography',
    subcategory: 'Symmetric Encryption',
    difficulty: 'Easy',
    points: 50,
    challengeType: 'flag',
    flag: 'CTF{xor_crypto_basics}',
    tags: ['cryptography', 'xor', 'symmetric'],
    learningObjectives: ['Understand XOR encryption', 'Perform XOR decryption']
  },
  {
    title: 'AES Encryption',
    slug: 'aes-encryption',
    description: 'Decrypt the AES-256-CBC encrypted message. Key: 00112233445566778899aabbccddeeff, IV: 000102030405060708090a0b0c0d0e0f',
    category: 'Cryptography',
    subcategory: 'Symmetric Encryption',
    difficulty: 'Medium',
    points: 150,
    challengeType: 'flag',
    flag: 'CTF{aes_decryption_successful}',
    tags: ['cryptography', 'aes', 'symmetric'],
    learningObjectives: ['Understand AES encryption', 'Perform AES decryption']
  },
  {
    title: 'RSA Basics',
    slug: 'rsa-basics',
    description: 'Given n=3233, e=17, d=2753. Encrypt the message M=65 using RSA. The flag is the ciphertext.',
    category: 'Cryptography',
    subcategory: 'Asymmetric Encryption',
    difficulty: 'Medium',
    points: 175,
    challengeType: 'flag',
    flag: 'CTF{2790}',
    tags: ['cryptography', 'rsa', 'asymmetric'],
    learningObjectives: ['Understand RSA algorithm', 'Perform RSA encryption']
  },
  {
    title: 'Hash Collision',
    slug: 'hash-collision',
    description: 'Find two different strings that produce the same MD5 hash prefix (first 6 chars).',
    category: 'Cryptography',
    subcategory: 'Hashing',
    difficulty: 'Hard',
    points: 300,
    challengeType: 'flag',
    flag: 'CTF{md5_collision_found}',
    tags: ['cryptography', 'md5', 'hashing', 'collision'],
    learningObjectives: ['Understand hash functions', 'Find hash collisions']
  },
  {
    title: 'Digital Signatures',
    slug: 'digital-signatures',
    description: 'Verify the RSA signature for the message. The public key is (e=65537, n=...) and signature is S=...',
    category: 'Cryptography',
    subcategory: 'Digital Signatures',
    difficulty: 'Hard',
    points: 250,
    challengeType: 'flag',
    flag: 'CTF{signature_verified_valid}',
    tags: ['cryptography', 'rsa', 'signatures', 'pkcs'],
    learningObjectives: ['Understand digital signatures', 'Verify RSA signatures']
  },
  {
    title: 'SSL/TLS Handshake',
    slug: 'ssl-tls-handshake',
    description: 'Analyze the TLS handshake in the provided PCAP. Identify the cipher suite negotiated.',
    category: 'Cryptography',
    subcategory: 'SSL/TLS',
    difficulty: 'Medium',
    points: 150,
    challengeType: 'file_analysis',
    flag: 'CTF{TLS_ECDHE_RSA_AES_256_GCM_SHA384}',
    tags: ['cryptography', 'tls', 'ssl', 'networking'],
    learningObjectives: ['Understand TLS handshake', 'Identify cipher suites']
  },
  {
    title: 'Password Cracking - MD5',
    slug: 'password-cracking-md5',
    description: 'Crack the MD5 hash: 5f4dcc3b5aa765d61d8327deb882cf99',
    category: 'Cryptography',
    subcategory: 'Password Cracking',
    difficulty: 'Easy',
    points: 50,
    challengeType: 'flag',
    flag: 'CTF{password}',
    tags: ['cryptography', 'md5', 'password-cracking', 'hashing'],
    learningObjectives: ['Crack MD5 hashes', 'Use rainbow tables']
  },
  {
    title: 'Password Cracking - bcrypt',
    slug: 'password-cracking-bcrypt',
    description: 'The bcrypt hash is $2b$10$N9qo8uLOickgx2ZMRZoMy.MqrqhmM6JGKpS4G3R1G2JH8YpfB0Bqy. Crack it.',
    category: 'Cryptography',
    subcategory: 'Password Cracking',
    difficulty: 'Insane',
    points: 500,
    challengeType: 'flag',
    flag: 'CTF{bcrypt_resistant_but_cracked}',
    tags: ['cryptography', 'bcrypt', 'password-cracking', 'advanced'],
    learningObjectives: ['Understand bcrypt', 'Advanced password cracking']
  },

  // === SYSTEM SECURITY ===
  {
    title: 'Linux File Permissions',
    slug: 'linux-file-permissions',
    description: 'Analyze the ls -la output. Find the file with SUID bit set that can be exploited for privilege escalation.',
    category: 'System Security',
    subcategory: 'Linux Security',
    difficulty: 'Easy',
    points: 75,
    challengeType: 'flag',
    flag: 'CTF{/usr/bin/find_suid_exploit}',
    tags: ['linux', 'permissions', 'privilege-escalation'],
    learningObjectives: ['Understand Linux permissions', 'Identify SUID binaries']
  },
  {
    title: 'Sudo Exploitation',
    slug: 'sudo-exploitation',
    description: 'The user can run vim as sudo without password. Escalate to root and read /root/flag.txt.',
    category: 'System Security',
    subcategory: 'Linux Privilege Escalation',
    difficulty: 'Medium',
    points: 150,
    challengeType: 'interactive_lab',
    flag: 'CTF{sudo_vim_privesc}',
    tags: ['linux', 'sudo', 'privilege-escalation'],
    learningObjectives: ['Exploit sudo misconfigurations', 'Linux privilege escalation']
  },
  {
    title: 'Windows Privilege Escalation',
    slug: 'windows-privilege-escalation',
    description: 'Use PowerUp to identify privilege escalation vectors on the Windows machine.',
    category: 'System Security',
    subcategory: 'Windows Security',
    difficulty: 'Hard',
    points: 275,
    challengeType: 'interactive_lab',
    flag: 'CTF{windows_service_misconfiguration}',
    tags: ['windows', 'privilege-escalation', 'powershell'],
    learningObjectives: ['Windows privilege escalation', 'Use PowerUp']
  },
  {
    title: 'Kernel Exploit',
    slug: 'kernel-exploit',
    description: 'The Linux kernel is vulnerable to CVE-2021-3493. Compile and run the exploit to get root.',
    category: 'System Security',
    subcategory: 'Kernel Exploitation',
    difficulty: 'Insane',
    points: 450,
    challengeType: 'interactive_lab',
    flag: 'CTF{kernel_exploit_successful_root}',
    tags: ['linux', 'kernel', 'exploit', 'privilege-escalation'],
    learningObjectives: ['Understand kernel exploits', 'Compile and run exploits']
  },
  {
    title: 'Container Escape',
    slug: 'container-escape',
    description: 'Escape from the Docker container to the host. The Docker socket is mounted inside.',
    category: 'System Security',
    subcategory: 'Container Security',
    difficulty: 'Hard',
    points: 350,
    challengeType: 'interactive_lab',
    flag: 'CTF{docker_socket_escape_complete}',
    tags: ['docker', 'container', 'escape', 'privilege-escalation'],
    learningObjectives: ['Understand container security', 'Escape Docker containers']
  },

  // === BINARY EXPLOITATION ===
  {
    title: 'Buffer Overflow 101',
    slug: 'buffer-overflow-101',
    description: 'Overflow the buffer to overwrite the return address. The binary has no protections.',
    category: 'Binary Exploitation',
    subcategory: 'Buffer Overflow',
    difficulty: 'Easy',
    points: 150,
    challengeType: 'interactive_lab',
    flag: 'CTF{buffer_overflow_exploited}',
    tags: ['binary', 'buffer-overflow', 'pwn', 'stack'],
    learningObjectives: ['Understand stack layout', 'Exploit buffer overflows']
  },
  {
    title: 'Stack Canary Bypass',
    slug: 'stack-canary-bypass',
    description: 'The binary has stack canaries enabled. Leak the canary value and bypass the protection.',
    category: 'Binary Exploitation',
    subcategory: 'Buffer Overflow',
    difficulty: 'Hard',
    points: 350,
    challengeType: 'interactive_lab',
    flag: 'CTF{canary_leaked_and_bypassed}',
    tags: ['binary', 'buffer-overflow', 'canary', 'pwn'],
    learningObjectives: ['Understand stack canaries', 'Leak and bypass canaries']
  },
  {
    title: 'Return-to-libc',
    slug: 'return-to-libc',
    description: 'NX is enabled but ASLR is off. Use return-to-libc to spawn a shell.',
    category: 'Binary Exploitation',
    subcategory: 'Return-to-libc',
    difficulty: 'Hard',
    points: 400,
    challengeType: 'interactive_lab',
    flag: 'CTF{ret2libc_shell_spawned}',
    tags: ['binary', 'ret2libc', 'nx', 'pwn'],
    learningObjectives: ['Understand NX bypass', 'Use return-to-libc']
  },
  {
    title: 'Heap Exploitation',
    slug: 'heap-exploitation',
    description: 'Exploit the use-after-free vulnerability in the heap allocator to get arbitrary write.',
    category: 'Binary Exploitation',
    subcategory: 'Heap',
    difficulty: 'Insane',
    points: 500,
    challengeType: 'interactive_lab',
    flag: 'CTF{heap_uaf_arbitrary_write}',
    tags: ['binary', 'heap', 'uaf', 'pwn', 'advanced'],
    learningObjectives: ['Understand heap internals', 'Exploit use-after-free']
  },
  {
    title: 'Shellcoding Basics',
    slug: 'shellcoding-basics',
    description: 'Write a shellcode that spawns /bin/sh. The buffer is executable. No null bytes allowed.',
    category: 'Binary Exploitation',
    subcategory: 'Shellcoding',
    difficulty: 'Medium',
    points: 250,
    challengeType: 'interactive_lab',
    flag: 'CTF{shellcode_execution_success}',
    tags: ['binary', 'shellcode', 'assembly', 'pwn'],
    learningObjectives: ['Write shellcode', 'Avoid bad characters']
  },

  // === NETWORK ATTACKS ===
  {
    title: 'MITM Attack',
    slug: 'mitm-attack',
    description: 'Perform a man-in-the-middle attack on the network. Capture the FTP credentials.',
    category: 'Network Attacks',
    subcategory: 'MITM',
    difficulty: 'Medium',
    points: 200,
    challengeType: 'interactive_lab',
    flag: 'CTF{ftp_credentials_captured}',
    tags: ['mitm', 'network', 'ftp', 'packet-capture'],
    learningObjectives: ['Perform MITM attacks', 'Capture credentials']
  },
  {
    title: 'Wireshark Analysis',
    slug: 'wireshark-analysis',
    description: 'Analyze the PCAP file to find the exfiltrated data. The flag is hidden in DNS queries.',
    category: 'Network Attacks',
    subcategory: 'Packet Analysis',
    difficulty: 'Medium',
    points: 175,
    challengeType: 'file_analysis',
    flag: 'CTF{dns_exfiltration_detected}',
    tags: ['wireshark', 'pcap', 'dns', 'exfiltration'],
    learningObjectives: ['Analyze PCAP files', 'Detect DNS exfiltration']
  },
  {
    title: 'DoS Simulation',
    slug: 'dos-simulation',
    description: 'Simulate a SYN flood attack. The server crashes after receiving 1000 SYN packets without ACK.',
    category: 'Network Attacks',
    subcategory: 'DoS/DDoS',
    difficulty: 'Easy',
    points: 100,
    challengeType: 'interactive_lab',
    flag: 'CTF{syn_flood_dos_successful}',
    tags: ['dos', 'syn-flood', 'network', 'attack'],
    learningObjectives: ['Understand DoS attacks', 'Perform SYN flood']
  },
  {
    title: 'ARP Poisoning',
    slug: 'arp-poisoning',
    description: 'Poison the ARP cache to redirect traffic through your machine. Capture the HTTP password.',
    category: 'Network Attacks',
    subcategory: 'ARP Poisoning',
    difficulty: 'Medium',
    points: 200,
    challengeType: 'interactive_lab',
    flag: 'CTF{arp_poison_http_password}',
    tags: ['arp', 'poisoning', 'mitm', 'network'],
    learningObjectives: ['Perform ARP poisoning', 'Capture network traffic']
  },

  // === DIGITAL FORENSICS ===
  {
    title: 'Log Analysis',
    slug: 'log-analysis',
    description: 'Analyze the Apache access logs to find the SQL injection attempt. Extract the attack payload.',
    category: 'Digital Forensics',
    subcategory: 'Log Analysis',
    difficulty: 'Easy',
    points: 100,
    challengeType: 'file_analysis',
    flag: 'CTF{union_select_admin_password}',
    tags: ['forensics', 'logs', 'sql-injection', 'analysis'],
    learningObjectives: ['Analyze web logs', 'Identify attack patterns']
  },
  {
    title: 'Disk Forensics',
    slug: 'disk-forensics',
    description: 'Mount the provided disk image. Find the deleted file containing the flag in the unallocated space.',
    category: 'Digital Forensics',
    subcategory: 'Disk Forensics',
    difficulty: 'Hard',
    points: 300,
    challengeType: 'file_analysis',
    flag: 'CTF{deleted_file_recovered}',
    tags: ['forensics', 'disk', 'recovery', 'sleuthkit'],
    learningObjectives: ['Analyze disk images', 'Recover deleted files']
  },
  {
    title: 'Memory Forensics',
    slug: 'memory-forensics',
    description: 'Analyze the Windows memory dump. Find the malicious process and extract its command line.',
    category: 'Digital Forensics',
    subcategory: 'Memory Forensics',
    difficulty: 'Hard',
    points: 350,
    challengeType: 'file_analysis',
    flag: 'CTF{malicious_process_found_volatility}',
    tags: ['forensics', 'memory', 'volatility', 'windows'],
    learningObjectives: ['Analyze memory dumps', 'Use Volatility framework']
  },
  {
    title: 'Steganography - Image',
    slug: 'steganography-image',
    description: 'The image contains hidden data. Use steghide or zsteg to extract the flag. Password: password123',
    category: 'Digital Forensics',
    subcategory: 'Steganography',
    difficulty: 'Easy',
    points: 75,
    challengeType: 'file_analysis',
    flag: 'CTF{steganography_image_hidden}',
    tags: ['forensics', 'steganography', 'image', 'hidden-data'],
    learningObjectives: ['Extract hidden data from images', 'Use steganography tools']
  },
  {
    title: 'Steganography - Audio',
    slug: 'steganography-audio',
    description: 'The WAV file contains hidden morse code in the least significant bits. Decode it.',
    category: 'Digital Forensics',
    subcategory: 'Steganography',
    difficulty: 'Medium',
    points: 150,
    challengeType: 'file_analysis',
    flag: 'CTF{audio_lsb_morse_code}',
    tags: ['forensics', 'steganography', 'audio', 'lsb'],
    learningObjectives: ['Extract LSB data', 'Decode morse code']
  },
  {
    title: 'Network Forensics',
    slug: 'network-forensics',
    description: 'A data breach occurred. Analyze the network capture to identify the exfiltrated file and its contents.',
    category: 'Digital Forensics',
    subcategory: 'Network Forensics',
    difficulty: 'Hard',
    points: 300,
    challengeType: 'file_analysis',
    flag: 'CTF{data_exfiltration_identified}',
    tags: ['forensics', 'network', 'pcap', 'exfiltration'],
    learningObjectives: ['Analyze network traffic', 'Identify data exfiltration']
  },

  // === MALWARE ANALYSIS ===
  {
    title: 'Static Analysis',
    slug: 'static-analysis',
    description: 'Analyze the provided PE file without executing it. Identify the imported functions and strings.',
    category: 'Malware Analysis',
    subcategory: 'Static Analysis',
    difficulty: 'Easy',
    points: 100,
    challengeType: 'file_analysis',
    flag: 'CTF{pe_imports_analyzed}',
    tags: ['malware', 'static-analysis', 'pe', 'strings'],
    learningObjectives: ['Perform static analysis', 'Analyze PE files']
  },
  {
    title: 'Dynamic Analysis',
    slug: 'dynamic-analysis',
    description: 'Run the malware in a sandbox. Monitor its behavior and identify the C2 server domain.',
    category: 'Malware Analysis',
    subcategory: 'Dynamic Analysis',
    difficulty: 'Medium',
    points: 200,
    challengeType: 'interactive_lab',
    flag: 'CTF{c2_server_evil.com}',
    tags: ['malware', 'dynamic-analysis', 'sandbox', 'c2'],
    learningObjectives: ['Perform dynamic analysis', 'Identify C2 communication']
  },
  {
    title: 'Reverse Engineering',
    slug: 'reverse-engineering',
    description: 'Reverse engineer the binary to find the password check algorithm. Crack the password.',
    category: 'Malware Analysis',
    subcategory: 'Reverse Engineering',
    difficulty: 'Hard',
    points: 350,
    challengeType: 'interactive_lab',
    flag: 'CTF{reverse_engineered_password}',
    tags: ['malware', 'reverse-engineering', 'ida', 'ghidra'],
    learningObjectives: ['Use disassemblers', 'Reverse engineer algorithms']
  },
  {
    title: 'Ransomware Analysis',
    slug: 'ransomware-analysis',
    description: 'Analyze the ransomware sample. Find the encryption key and decrypt the provided file.',
    category: 'Malware Analysis',
    subcategory: 'Ransomware',
    difficulty: 'Insane',
    points: 500,
    challengeType: 'interactive_lab',
    flag: 'CTF{ransomware_decrypted_key_found}',
    tags: ['malware', 'ransomware', 'reverse-engineering', 'cryptography'],
    learningObjectives: ['Analyze ransomware', 'Extract encryption keys']
  },

  // === WIRELESS SECURITY ===
  {
    title: 'WPA2 Cracking',
    slug: 'wpa2-cracking',
    description: 'Crack the WPA2 handshake using aircrack-ng and the provided wordlist. The password is in rockyou.txt.',
    category: 'Wireless Security',
    subcategory: 'WPA/WPA2',
    difficulty: 'Medium',
    points: 175,
    challengeType: 'file_analysis',
    flag: 'CTF{wpa2_password_cracked}',
    tags: ['wireless', 'wpa2', 'cracking', 'wifi'],
    learningObjectives: ['Capture WPA handshakes', 'Crack WPA2 passwords']
  },
  {
    title: 'WiFi Deauth Attack',
    slug: 'wifi-deauth-attack',
    description: 'Understand how deauthentication attacks work. Analyze the provided capture to identify the attack.',
    category: 'Wireless Security',
    subcategory: 'WiFi Attacks',
    difficulty: 'Easy',
    points: 75,
    challengeType: 'file_analysis',
    flag: 'CTF{deauth_attack_detected}',
    tags: ['wireless', 'deauth', 'wifi', 'attack'],
    learningObjectives: ['Understand deauth attacks', 'Analyze wireless captures']
  },

  // === CLOUD SECURITY ===
  {
    title: 'AWS S3 Bucket',
    slug: 'aws-s3-bucket',
    description: 'The S3 bucket has misconfigured permissions. List the bucket contents and find the flag file.',
    category: 'Cloud Security',
    subcategory: 'AWS',
    difficulty: 'Easy',
    points: 100,
    challengeType: 'interactive_lab',
    flag: 'CTF{s3_bucket_misconfigured_public}',
    tags: ['cloud', 'aws', 's3', 'misconfiguration'],
    learningObjectives: ['Identify S3 misconfigurations', 'Exploit public buckets']
  },
  {
    title: 'IAM Privilege Escalation',
    slug: 'iam-privilege-escalation',
    description: 'The IAM user has iam:PassRole permission. Escalate privileges to admin by creating an EC2 instance.',
    category: 'Cloud Security',
    subcategory: 'AWS IAM',
    difficulty: 'Hard',
    points: 350,
    challengeType: 'interactive_lab',
    flag: 'CTF{iam_privilege_escalation_aws}',
    tags: ['cloud', 'aws', 'iam', 'privilege-escalation'],
    learningObjectives: ['Understand IAM policies', 'Cloud privilege escalation']
  },
  {
    title: 'Container Escape K8s',
    slug: 'container-escape-k8s',
    description: 'Escape from the Kubernetes pod to the node. The pod has hostPath volume mounted.',
    category: 'Cloud Security',
    subcategory: 'Kubernetes',
    difficulty: 'Hard',
    points: 400,
    challengeType: 'interactive_lab',
    flag: 'CTF{k8s_container_escape_node}',
    tags: ['cloud', 'kubernetes', 'container', 'escape'],
    learningObjectives: ['Understand Kubernetes security', 'Escape containers in K8s']
  },

  // === API SECURITY ===
  {
    title: 'API Authentication Bypass',
    slug: 'api-authentication-bypass',
    description: 'The API uses API keys in query parameters. Find the admin API key by analyzing the client-side code.',
    category: 'Modern Topics',
    subcategory: 'API Security',
    difficulty: 'Easy',
    points: 100,
    challengeType: 'interactive_lab',
    flag: 'CTF{api_key_exposed_client_side}',
    tags: ['api', 'authentication', 'bypass', 'web'],
    learningObjectives: ['Identify API vulnerabilities', 'Bypass API authentication']
  },
  {
    title: 'GraphQL Injection',
    slug: 'graphql-injection',
    description: 'The GraphQL endpoint is vulnerable to injection. Extract all user passwords using introspection.',
    category: 'Modern Topics',
    subcategory: 'API Security',
    difficulty: 'Hard',
    points: 300,
    challengeType: 'interactive_lab',
    flag: 'CTF{graphql_injection_all_users}',
    tags: ['api', 'graphql', 'injection', 'advanced'],
    learningObjectives: ['Understand GraphQL', 'Exploit GraphQL injection']
  },
  {
    title: 'JWT Weak Secret',
    slug: 'jwt-weak-secret',
    description: 'The JWT uses a weak secret from a common wordlist. Crack the secret and forge an admin token.',
    category: 'Modern Topics',
    subcategory: 'API Security',
    difficulty: 'Medium',
    points: 200,
    challengeType: 'interactive_lab',
    flag: 'CTF{jwt_secret_cracked_forged}',
    tags: ['api', 'jwt', 'cracking', 'web'],
    learningObjectives: ['Crack JWT secrets', 'Forge JWT tokens']
  },

  // === DEVSECOPS ===
  {
    title: 'CI/CD Pipeline',
    slug: 'cicd-pipeline',
    description: 'The CI/CD pipeline has a secret in environment variables. Extract it from the build logs.',
    category: 'Modern Topics',
    subcategory: 'DevSecOps',
    difficulty: 'Easy',
    points: 75,
    challengeType: 'interactive_lab',
    flag: 'CTF{cicd_secret_exposed}',
    tags: ['devsecops', 'cicd', 'secrets', 'pipeline'],
    learningObjectives: ['Identify CI/CD vulnerabilities', 'Extract secrets from logs']
  },
  {
    title: 'Infrastructure as Code',
    slug: 'infrastructure-as-code',
    description: 'The Terraform configuration has security misconfigurations. Identify the publicly exposed database.',
    category: 'Modern Topics',
    subcategory: 'DevSecOps',
    difficulty: 'Medium',
    points: 150,
    challengeType: 'flag',
    flag: 'CTF{terraform_db_publicly_exposed}',
    tags: ['devsecops', 'terraform', 'iac', 'misconfiguration'],
    learningObjectives: ['Review IaC security', 'Identify misconfigurations']
  },

  // === PROGRAMMING ===
  {
    title: 'Python Scripting',
    slug: 'python-scripting',
    description: 'Write a Python script to brute force the 4-digit PIN on the login page.',
    category: 'Programming',
    subcategory: 'Scripting',
    difficulty: 'Easy',
    points: 75,
    challengeType: 'interactive_lab',
    flag: 'CTF{python_bruteforce_1337}',
    tags: ['programming', 'python', 'scripting', 'bruteforce'],
    learningObjectives: ['Write Python scripts', 'Automate attacks']
  },
  {
    title: 'Bash Scripting',
    slug: 'bash-scripting',
    description: 'Write a bash one-liner to find all SUID files and check for known exploits.',
    category: 'Programming',
    subcategory: 'Scripting',
    difficulty: 'Medium',
    points: 125,
    challengeType: 'interactive_lab',
    flag: 'CTF{bash_suid_finder_exploit}',
    tags: ['programming', 'bash', 'scripting', 'linux'],
    learningObjectives: ['Write bash scripts', 'Automate Linux enumeration']
  },

  // === MISCELLANEOUS ===
  {
    title: 'Git History',
    slug: 'git-history',
    description: 'The repository contains a secret in the git history. Use git log and git show to find it.',
    category: 'Miscellaneous',
    subcategory: 'Git',
    difficulty: 'Easy',
    points: 50,
    challengeType: 'interactive_lab',
    flag: 'CTF{git_history_secret_found}',
    tags: ['misc', 'git', 'secrets', 'history'],
    learningObjectives: ['Analyze git history', 'Find hidden secrets']
  },
  {
    title: 'QR Code',
    slug: 'qr-code',
    description: 'Decode the QR code image to reveal the flag.',
    category: 'Miscellaneous',
    subcategory: 'Steganography',
    difficulty: 'Easy',
    points: 25,
    challengeType: 'file_analysis',
    flag: 'CTF{qr_code_decoded}',
    tags: ['misc', 'qr', 'steganography'],
    learningObjectives: ['Decode QR codes', 'Use image analysis tools']
  },
  {
    title: 'Memory Dump Password',
    slug: 'memory-dump-password',
    description: 'The memory dump contains a password in plaintext. Use strings and grep to find it.',
    category: 'Miscellaneous',
    subcategory: 'Forensics',
    difficulty: 'Easy',
    points: 50,
    challengeType: 'file_analysis',
    flag: 'CTF{memory_strings_password}',
    tags: ['misc', 'memory', 'strings', 'forensics'],
    learningObjectives: ['Extract strings from memory', 'Use grep effectively']
  }
];

// Badges seed data
const badges = [
  {
    name: 'First Blood',
    description: 'Solve your first challenge',
    icon: 'sword',
    color: '#ef4444',
    category: 'achievement',
    criteria: { type: 'challenges_solved', value: 1 },
    rarity: 'common'
  },
  {
    name: 'Script Kiddie',
    description: 'Solve 10 challenges',
    icon: 'terminal',
    color: '#22c55e',
    category: 'achievement',
    criteria: { type: 'challenges_solved', value: 10 },
    rarity: 'common'
  },
  {
    name: 'Web Warrior',
    description: 'Solve 5 Web Security challenges',
    icon: 'globe',
    color: '#3b82f6',
    category: 'skill',
    criteria: { type: 'category_mastery', value: 5, category: 'Web Security' },
    rarity: 'uncommon'
  },
  {
    name: 'Crypto Master',
    description: 'Solve 10 Cryptography challenges',
    icon: 'key',
    color: '#a855f7',
    category: 'skill',
    criteria: { type: 'category_mastery', value: 10, category: 'Cryptography' },
    rarity: 'rare'
  },
  {
    name: 'Binary Ninja',
    description: 'Solve 5 Binary Exploitation challenges',
    icon: 'cpu',
    color: '#f59e0b',
    category: 'skill',
    criteria: { type: 'category_mastery', value: 5, category: 'Binary Exploitation' },
    rarity: 'epic'
  },
  {
    name: 'Elite Hacker',
    description: 'Reach 5000 points',
    icon: 'crown',
    color: '#eab308',
    category: 'achievement',
    criteria: { type: 'points_earned', value: 5000 },
    rarity: 'legendary'
  },
  {
    name: 'Streak Master',
    description: 'Maintain a 7-day solving streak',
    icon: 'flame',
    color: '#f97316',
    category: 'achievement',
    criteria: { type: 'streak', value: 7 },
    rarity: 'rare'
  },
  {
    name: 'First Blood Hunter',
    description: 'Get first blood on a challenge',
    icon: 'droplet',
    color: '#dc2626',
    category: 'special',
    criteria: { type: 'special', value: 1 },
    rarity: 'epic'
  }
];

async function seedDatabase() {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/ctf_platform');

    // Clear existing data
    await Challenge.deleteMany({});
    await Badge.deleteMany({});

    // Insert challenges
    const createdChallenges = await Challenge.insertMany(challenges);
    console.log(`✅ Created ${createdChallenges.length} challenges`);

    // Insert badges
    const createdBadges = await Badge.insertMany(badges);
    console.log(`✅ Created ${createdBadges.length} badges`);

    // Print statistics
    const categories = {};
    createdChallenges.forEach(c => {
      categories[c.category] = (categories[c.category] || 0) + 1;
    });

    console.log('\n📊 Challenge Distribution:');
    Object.entries(categories).forEach(([cat, count]) => {
      console.log(`   ${cat}: ${count}`);
    });

    console.log(`\n🎯 Total Challenges: ${createdChallenges.length}`);
    console.log('✅ Database seeded successfully!');

    process.exit(0);
  } catch (error) {
    console.error('❌ Seeding failed:', error);
    process.exit(1);
  }
}

seedDatabase();
