const mongoose = require('mongoose');

const progressSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  categories: {
    type: Map,
    of: {
      completed: { type: Number, default: 0 },
      total: { type: Number, default: 0 },
      points: { type: Number, default: 0 }
    }
  },
  skills: {
    type: Map,
    of: {
      level: { type: Number, default: 0 }, // 0-100
      experience: { type: Number, default: 0 }
    }
  },
  dailyProgress: [{
    date: Date,
    challengesSolved: Number,
    pointsEarned: Number,
    timeSpent: Number // minutes
  }],
  weeklyStats: {
    weekStart: Date,
    challengesSolved: { type: Number, default: 0 },
    pointsEarned: { type: Number, default: 0 },
    rank: Number
  }
}, { timestamps: true });

module.exports = mongoose.model('Progress', progressSchema);
