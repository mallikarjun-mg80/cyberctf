const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  description: String,
  type: {
    type: String,
    enum: ['individual', 'team', 'battle_royale', 'jeopardy', 'attack_defense'],
    default: 'individual'
  },
  status: {
    type: String,
    enum: ['upcoming', 'active', 'paused', 'ended'],
    default: 'upcoming'
  },
  startTime: {
    type: Date,
    required: true
  },
  endTime: {
    type: Date,
    required: true
  },
  challenges: [{
    challenge: { type: mongoose.Schema.Types.ObjectId, ref: 'Challenge' },
    points: Number,
    isUnlocked: { type: Boolean, default: false }
  }],
  participants: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    team: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
    joinedAt: { type: Date, default: Date.now },
    score: { type: Number, default: 0 },
    solves: [{ challenge: mongoose.Schema.Types.ObjectId, solvedAt: Date }]
  }],
  rules: [String],
  prizes: [{
    rank: Number,
    description: String,
    value: String
  }],
  isPublic: { type: Boolean, default: true },
  maxParticipants: { type: Number, default: 0 }, // 0 = unlimited
  requiresApproval: { type: Boolean, default: false }
}, { timestamps: true });

module.exports = mongoose.model('Event', eventSchema);
