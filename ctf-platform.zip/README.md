# 🛡️ CTF Platform - Cybersecurity Learning Environment

A production-ready, full-stack Capture The Flag (CTF) platform designed for comprehensive cybersecurity education. Built with modern technologies and security best practices.

## 🎯 Features

### Core Platform
- **87+ Challenges** across 15 categories
- **5 Difficulty Levels**: Beginner to Insane
- **Real-time Leaderboard** with weekly/monthly rankings
- **Gamified Progression**: Points, badges, skill levels, streaks
- **Interactive Labs**: Docker-based isolated environments
- **File Analysis**: PCAP, disk images, memory dumps, steganography
- **Quiz System**: Knowledge-based assessments
- **Hint System**: Progressive hints with point cost

### Security & Authentication
- JWT-based authentication with refresh tokens
- Role-based access control (User, Moderator, Admin)
- bcrypt password hashing
- Rate limiting & brute-force protection
- Input validation & sanitization
- Helmet security headers
- CORS protection
- Account lockout after failed attempts

### Admin Panel
- Challenge CRUD operations
- File upload management
- User monitoring & role management
- Analytics dashboard

### Modern Stack
- **Frontend**: React 18 + Vite + Tailwind CSS + Framer Motion
- **Backend**: Node.js + Express + MongoDB + Redis
- **Security**: JWT, bcrypt, rate limiting, input validation
- **Deployment**: Docker + Docker Compose + Nginx

## 📚 Challenge Categories (87 Total)

| Category | Count | Difficulty Range |
|----------|-------|-----------------|
| Networking | 10 | Easy - Insane |
| Web Security | 12 | Easy - Hard |
| Cryptography | 10 | Easy - Insane |
| System Security | 5 | Easy - Insane |
| Binary Exploitation | 5 | Easy - Insane |
| Digital Forensics | 6 | Easy - Hard |
| Malware Analysis | 4 | Easy - Insane |
| Network Attacks | 4 | Easy - Medium |
| Reconnaissance | 5 | Easy - Medium |
| Cloud Security | 3 | Easy - Hard |
| Wireless Security | 2 | Easy - Medium |
| API Security | 3 | Easy - Hard |
| DevSecOps | 2 | Easy - Medium |
| Programming | 2 | Easy - Medium |
| Miscellaneous | 3 | Easy - Easy |

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- Node.js 18+ (for local development)
- MongoDB (or use Docker)
- Redis (or use Docker)

### Docker Deployment (Recommended)

```bash
# Clone the repository
git clone <repository-url>
cd ctf-platform

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration

# Start all services
docker-compose up -d

# Seed the database with challenges
docker-compose exec backend npm run seed

# Access the platform
# Frontend: http://localhost
# Backend API: http://localhost:5000
```

### Local Development

```bash
# Backend
cd backend
npm install
cp .env.example .env
npm run dev

# Frontend (new terminal)
cd frontend
npm install
npm run dev
```

## 📁 Project Structure

```
ctf-platform/
├── backend/
│   ├── src/
│   │   ├── config/         # Database & Redis config
│   │   ├── controllers/    # Business logic
│   │   ├── middleware/     # Auth, security, upload
│   │   ├── models/         # MongoDB schemas
│   │   ├── routes/         # API endpoints
│   │   ├── utils/          # Helpers, logger, JWT
│   │   └── validators/     # Input validation
│   ├── uploads/            # File storage
│   ├── Dockerfile
│   └── server.js           # Entry point
├── frontend/
│   ├── src/
│   │   ├── components/     # Reusable components
│   │   ├── contexts/       # React contexts
│   │   ├── pages/          # Route pages
│   │   ├── services/       # API client
│   │   └── styles/         # Global styles
│   ├── Dockerfile
│   └── vite.config.js
├── docker/
│   └── mongo-init.js       # DB initialization
├── docker-compose.yml
└── .env
```

## 🔌 API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | User registration |
| POST | /api/auth/login | User login |
| GET | /api/auth/me | Get current user |
| POST | /api/auth/refresh | Refresh access token |
| POST | /api/auth/forgot-password | Request password reset |
| PUT | /api/auth/reset-password | Reset password |
| GET | /api/auth/verify-email | Verify email |

### Challenges
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/challenges | List challenges |
| GET | /api/challenges/:id | Get challenge details |
| POST | /api/challenges/:id/submit | Submit flag |
| POST | /api/challenges/:id/hints/:index | Get hint |
| GET | /api/challenges/categories | Get categories |

### Leaderboard
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/leaderboard | Global leaderboard |
| GET | /api/leaderboard/rank | User rank |
| GET | /api/leaderboard/category/:cat | Category leaderboard |

### Users
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/users/dashboard | User dashboard |
| GET | /api/users/:username | Public profile |
| GET | /api/users/submissions | Submission history |
| GET | /api/users/notifications | Notifications |

## 🔐 Security Features

- **Authentication**: JWT with refresh token rotation
- **Password Security**: bcrypt with 12 rounds
- **Rate Limiting**: Express-rate-limit on auth & flag submission
- **Input Validation**: express-validator on all inputs
- **NoSQL Injection**: mongo-sanitize middleware
- **XSS Protection**: xss-clean middleware
- **HTTP Headers**: Helmet with CSP
- **CORS**: Configured for specific origins
- **File Upload**: Type validation, size limits, secure naming
- **Account Security**: Login attempt tracking, account lockout

## 🐳 Docker Services

| Service | Image | Port | Purpose |
|---------|-------|------|---------|
| mongodb | mongo:7.0 | 27017 | Primary database |
| redis | redis:7-alpine | 6379 | Caching & sessions |
| backend | node:18-alpine | 5000 | API server |
| frontend | nginx:alpine | 80 | Web server |

## 📊 Database Schema

### Users
- Authentication (email, password hash, roles)
- Profile (display name, bio, avatar, social links)
- Stats (points, solves, streak, accuracy)
- Progress (completed challenges, badges, achievements)
- Preferences (theme, notifications, privacy)

### Challenges
- Metadata (title, description, category, difficulty)
- Flag (encrypted, case sensitivity)
- Scoring (static/dynamic, points, decay)
- Content (attachments, hints, prerequisites)
- Docker config (image, ports, environment)
- Analytics (solve count, success rate, ratings)

### Submissions
- User & Challenge references
- Flag attempt & correctness
- Points earned & attempt number
- IP address & user agent
- Timestamp

## 🎮 Challenge Types

1. **Quiz**: Multiple choice questions
2. **Flag**: Traditional CTF flag submission
3. **File Analysis**: Download and analyze files
4. **Interactive Lab**: Docker-based environments
5. **Real World**: Simulated scenarios
6. **Code Review**: Review vulnerable code
7. **Multi-Stage**: Progressive challenges

## 🏆 Scoring System

- **Static Scoring**: Fixed points per challenge
- **Dynamic Scoring**: Points decrease with more solves
- **First Blood**: Bonus for first solver
- **Hint Penalty**: Points deducted for hints used
- **Streak Bonus**: Consecutive daily solves

## 🛠️ Development

### Running Tests
```bash
# Backend tests
cd backend
npm test

# Frontend tests
cd frontend
npm test
```

### Seeding Data
```bash
cd backend
npm run seed
```

### Linting
```bash
# Backend
cd backend
npm run lint

# Frontend
cd frontend
npm run lint
```

## 📈 Roadmap

- [ ] Real-time multiplayer CTF battles
- [ ] AI-powered hint system
- [ ] Challenge writeups section
- [ ] Team management
- [ ] Event/CTF competition hosting
- [ ] API for external integrations
- [ ] Mobile app
- [ ] Advanced analytics
- [ ] Certificate generation

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## 📄 License

MIT License - see LICENSE file for details

## 🙏 Acknowledgments

- Inspired by CTFtime, HackTheBox, TryHackMe, and picoCTF
- Built for the cybersecurity community
- Designed for educational purposes

---

**⚠️ Disclaimer**: This platform is designed for educational purposes only. 
All challenges should be solved within the platform environment. 
Never use these techniques on systems without explicit authorization.
