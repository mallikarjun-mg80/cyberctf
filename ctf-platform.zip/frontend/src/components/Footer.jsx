import React from 'react';
import { Shield, Github, Twitter, Heart } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Shield className="w-6 h-6 text-emerald-400" />
              <span className="text-lg font-bold text-white">CTF Platform</span>
            </div>
            <p className="text-slate-400 text-sm max-w-md">
              A comprehensive cybersecurity learning platform designed to help you master 
              offensive and defensive security through hands-on challenges.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/challenges" className="text-slate-400 hover:text-emerald-400 text-sm transition-colors">Challenges</a></li>
              <li><a href="/leaderboard" className="text-slate-400 hover:text-emerald-400 text-sm transition-colors">Leaderboard</a></li>
              <li><a href="/dashboard" className="text-slate-400 hover:text-emerald-400 text-sm transition-colors">Dashboard</a></li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-white font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-slate-400 hover:text-emerald-400 text-sm transition-colors">Documentation</a></li>
              <li><a href="#" className="text-slate-400 hover:text-emerald-400 text-sm transition-colors">API Reference</a></li>
              <li><a href="#" className="text-slate-400 hover:text-emerald-400 text-sm transition-colors">Writeups</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-8 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-slate-500 text-sm flex items-center gap-1">
            Made with <Heart className="w-4 h-4 text-red-500 fill-red-500" /> for the security community
          </p>
          <div className="flex items-center gap-4">
            <a href="#" className="text-slate-400 hover:text-white transition-colors">
              <Github className="w-5 h-5" />
            </a>
            <a href="#" className="text-slate-400 hover:text-white transition-colors">
              <Twitter className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
