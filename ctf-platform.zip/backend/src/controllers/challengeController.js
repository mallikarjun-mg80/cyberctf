const { Challenge, Submission, User, Notification } = require('../models');
const logger = require('../utils/logger');

// @desc    Get all challenges with filters
// @route   GET /api/challenges
// @access  Public/Private
exports.getChallenges = async (req, res) => {
  try {
    const {
      category,
      difficulty,
      search,
      sortBy = 'points',
      order = 'asc',
      page = 1,
      limit = 20,
      tags
    } = req.query;

    const query = { isActive: true, isVerified: true };

    if (category) query.category = category;
    if (difficulty) query.difficulty = difficulty;
    if (tags) query.tags = { $in: tags.split(',') };
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { tags: { $in: [new RegExp(search, 'i')] } }
      ];
    }

    const sortOptions = {};
    sortOptions[sortBy] = order === 'desc' ? -1 : 1;

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const challenges = await Challenge.find(query)
      .select('-flag')
      .populate('author', 'username profile.displayName')
      .sort(sortOptions)
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Challenge.countDocuments(query);

    // If user is authenticated, add completion status
    let challengesWithStatus = challenges;
    if (req.user) {
      const userSubmissions = await Submission.find({
        user: req.user.id,
        isCorrect: true
      }).select('challenge');

      const solvedIds = new Set(userSubmissions.map(s => s.challenge.toString()));

      challengesWithStatus = challenges.map(challenge => ({
        ...challenge.toObject(),
        isSolved: solvedIds.has(challenge._id.toString())
      }));
    }

    res.json({
      success: true,
      data: challengesWithStatus,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (error) {
    logger.error('Get challenges error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch challenges'
    });
  }
};

// @desc    Get single challenge
// @route   GET /api/challenges/:id
// @access  Public/Private
exports.getChallenge = async (req, res) => {
  try {
    const challenge = await Challenge.findById(req.params.id)
      .select('-flag')
      .populate('author', 'username profile.displayName')
      .populate('prerequisites', 'title slug difficulty');

    if (!challenge) {
      return res.status(404).json({
        success: false,
        message: 'Challenge not found'
      });
    }

    let userProgress = null;
    let isSolved = false;

    if (req.user) {
      const submissions = await Submission.find({
        user: req.user.id,
        challenge: challenge._id
      }).sort({ createdAt: -1 });

      isSolved = submissions.some(s => s.isCorrect);

      if (submissions.length > 0) {
        userProgress = {
          attempts: submissions.length,
          lastAttempt: submissions[0].createdAt,
          isSolved,
          hintsUsed: submissions[0].hintsUsed || []
        };
      }
    }

    res.json({
      success: true,
      data: {
        challenge,
        userProgress,
        isSolved
      }
    });
  } catch (error) {
    logger.error('Get challenge error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch challenge'
    });
  }
};

// @desc    Submit flag
// @route   POST /api/challenges/:id/submit
// @access  Private
exports.submitFlag = async (req, res) => {
  try {
    const { flag } = req.body;
    const challengeId = req.params.id;
    const userId = req.user.id;

    const challenge = await Challenge.findById(challengeId).select('+flag');

    if (!challenge) {
      return res.status(404).json({
        success: false,
        message: 'Challenge not found'
      });
    }

    // Check if already solved
    const alreadySolved = await Submission.hasSolved(userId, challengeId);
    if (alreadySolved) {
      return res.status(400).json({
        success: false,
        message: 'Challenge already solved'
      });
    }

    // Check attempt limits
    const attemptCount = await Submission.getAttemptCount(userId, challengeId);
    if (challenge.maxAttempts > 0 && attemptCount >= challenge.maxAttempts) {
      return res.status(403).json({
        success: false,
        message: `Maximum attempts (${challenge.maxAttempts}) reached`
      });
    }

    // Validate flag
    let isCorrect = false;
    if (challenge.flagCaseSensitive) {
      isCorrect = flag === challenge.flag;
    } else {
      isCorrect = flag.toLowerCase() === challenge.flag.toLowerCase();
    }

    // Calculate points (dynamic scoring)
    let pointsEarned = 0;
    if (isCorrect) {
      pointsEarned = challenge.calculateDynamicPoints();

      // Update challenge stats
      challenge.solveCount += 1;
      if (!challenge.firstBlood) {
        challenge.firstBlood = { user: userId, solvedAt: new Date() };
      }
      await challenge.save();

      // Update user stats
      const user = await User.findById(userId);
      user.stats.totalPoints += pointsEarned;
      user.stats.challengesSolved += 1;
      user.stats.successfulAttempts += 1;

      // Calculate accuracy
      const totalAttempts = user.stats.totalAttempts + 1;
      user.stats.accuracy = Math.round((user.stats.successfulAttempts / totalAttempts) * 100);

      // Update skill level
      user.skillLevel = user.calculateSkillLevel();

      // Add to completed challenges
      user.completedChallenges.push({
        challenge: challengeId,
        pointsEarned,
        attempts: attemptCount + 1
      });

      await user.save();

      // Create notification
      await Notification.create({
        user: userId,
        type: 'achievement_unlocked',
        title: 'Challenge Solved!',
        message: `You solved "${challenge.title}" and earned ${pointsEarned} points!`,
        data: { challengeId, pointsEarned }
      });
    }

    // Record submission
    const submission = await Submission.create({
      user: userId,
      challenge: challengeId,
      flag,
      isCorrect,
      pointsEarned,
      attemptNumber: attemptCount + 1,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent']
    });

    // Update total attempts
    if (!isCorrect) {
      await User.findByIdAndUpdate(userId, {
        $inc: { 'stats.totalAttempts': 1 }
      });
    }

    res.json({
      success: true,
      data: {
        correct: isCorrect,
        pointsEarned,
        attemptNumber: attemptCount + 1,
        message: isCorrect 
          ? `Congratulations! You earned ${pointsEarned} points!` 
          : 'Incorrect flag. Try again!'
      }
    });
  } catch (error) {
    logger.error('Submit flag error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to submit flag'
    });
  }
};

// @desc    Get hint
// @route   POST /api/challenges/:id/hints/:hintIndex
// @access  Private
exports.getHint = async (req, res) => {
  try {
    const { id, hintIndex } = req.params;
    const userId = req.user.id;

    const challenge = await Challenge.findById(id);
    if (!challenge) {
      return res.status(404).json({
        success: false,
        message: 'Challenge not found'
      });
    }

    const hint = challenge.hints[hintIndex];
    if (!hint) {
      return res.status(404).json({
        success: false,
        message: 'Hint not found'
      });
    }

    // Check if already solved
    const alreadySolved = await Submission.hasSolved(userId, id);
    if (alreadySolved) {
      return res.json({
        success: true,
        data: { hint: hint.content, cost: 0 }
      });
    }

    // Deduct points if hint has cost
    if (hint.cost > 0) {
      const user = await User.findById(userId);
      if (user.stats.totalPoints < hint.cost) {
        return res.status(400).json({
          success: false,
          message: `Insufficient points. Need ${hint.cost} points.`
        });
      }

      user.stats.totalPoints -= hint.cost;
      await user.save();
    }

    res.json({
      success: true,
      data: {
        hint: hint.content,
        cost: hint.cost
      }
    });
  } catch (error) {
    logger.error('Get hint error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get hint'
    });
  }
};

// @desc    Create challenge (Admin)
// @route   POST /api/challenges
// @access  Private/Admin
exports.createChallenge = async (req, res) => {
  try {
    const challengeData = {
      ...req.body,
      author: req.user.id
    };

    const challenge = await Challenge.create(challengeData);

    res.status(201).json({
      success: true,
      data: challenge
    });
  } catch (error) {
    logger.error('Create challenge error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create challenge'
    });
  }
};

// @desc    Update challenge (Admin)
// @route   PUT /api/challenges/:id
// @access  Private/Admin
exports.updateChallenge = async (req, res) => {
  try {
    const challenge = await Challenge.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!challenge) {
      return res.status(404).json({
        success: false,
        message: 'Challenge not found'
      });
    }

    res.json({
      success: true,
      data: challenge
    });
  } catch (error) {
    logger.error('Update challenge error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update challenge'
    });
  }
};

// @desc    Delete challenge (Admin)
// @route   DELETE /api/challenges/:id
// @access  Private/Admin
exports.deleteChallenge = async (req, res) => {
  try {
    const challenge = await Challenge.findByIdAndDelete(req.params.id);

    if (!challenge) {
      return res.status(404).json({
        success: false,
        message: 'Challenge not found'
      });
    }

    // Clean up submissions
    await Submission.deleteMany({ challenge: req.params.id });

    res.json({
      success: true,
      message: 'Challenge deleted successfully'
    });
  } catch (error) {
    logger.error('Delete challenge error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete challenge'
    });
  }
};

// @desc    Get challenge categories
// @route   GET /api/challenges/categories
// @access  Public
exports.getCategories = async (req, res) => {
  try {
    const categories = await Challenge.aggregate([
      { $match: { isActive: true, isVerified: true } },
      {
        $group: {
          _id: '$category',
          count: { $sum: 1 },
          difficulties: {
            $push: '$difficulty'
          }
        }
      },
      {
        $project: {
          category: '$_id',
          count: 1,
          easy: {
            $size: {
              $filter: {
                input: '$difficulties',
                cond: { $eq: ['$$this', 'Easy'] }
              }
            }
          },
          medium: {
            $size: {
              $filter: {
                input: '$difficulties',
                cond: { $eq: ['$$this', 'Medium'] }
              }
            }
          },
          hard: {
            $size: {
              $filter: {
                input: '$difficulties',
                cond: { $eq: ['$$this', 'Hard'] }
              }
            }
          },
          insane: {
            $size: {
              $filter: {
                input: '$difficulties',
                cond: { $eq: ['$$this', 'Insane'] }
              }
            }
          }
        }
      }
    ]);

    res.json({
      success: true,
      data: categories
    });
  } catch (error) {
    logger.error('Get categories error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch categories'
    });
  }
};
