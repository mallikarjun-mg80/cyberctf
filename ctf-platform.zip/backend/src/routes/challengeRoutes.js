const express = require('express');
const router = express.Router();
const challengeController = require('../controllers/challengeController');
const { authenticate, authorize } = require('../middleware/auth');
const { flagSubmissionLimiter } = require('../middleware/security');
const { challengeUpload, handleUploadError } = require('../middleware/upload');

// Public routes
router.get('/', challengeController.getChallenges);
router.get('/categories', challengeController.getCategories);
router.get('/:id', challengeController.getChallenge);

// Protected routes
router.post('/:id/submit', authenticate, flagSubmissionLimiter, challengeController.submitFlag);
router.post('/:id/hints/:hintIndex', authenticate, challengeController.getHint);

// Admin routes
router.post('/', authenticate, authorize('admin', 'moderator'), challengeController.createChallenge);
router.put('/:id', authenticate, authorize('admin', 'moderator'), challengeController.updateChallenge);
router.delete('/:id', authenticate, authorize('admin'), challengeController.deleteChallenge);

// File upload route
router.post('/:id/upload', 
  authenticate, 
  authorize('admin', 'moderator'),
  challengeUpload.array('files', 5),
  handleUploadError,
  (req, res) => {
    const files = req.files.map(file => ({
      filename: file.filename,
      originalName: file.originalname,
      size: file.size,
      path: file.path
    }));
    res.json({ success: true, data: files });
  }
);

module.exports = router;
