db = db.getSiblingDB('ctf_platform');

db.createUser({
  user: 'ctf_app',
  pwd: 'ctf_app_password',
  roles: [
    { role: 'readWrite', db: 'ctf_platform' }
  ]
});

// Create indexes
db.users.createIndex({ "username": 1 }, { unique: true });
db.users.createIndex({ "email": 1 }, { unique: true });
db.challenges.createIndex({ "slug": 1 }, { unique: true });
db.submissions.createIndex({ "user": 1, "challenge": 1 });

print('Database initialized successfully');
