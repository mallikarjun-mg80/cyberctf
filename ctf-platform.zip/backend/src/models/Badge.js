const mongoose = require('mongoose');

const badgeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true
  },
  description: {
    type: String,
    required: true
  },
  icon: {
    type: String,
    required: true
  },
  color: {
    type: String,
    default: '#6366f1'
  },
  category: {
    type: String,
    enum: ['skill', 'achievement', 'special', 'event'],
    default: 'achievement'
  },
  criteria: {
    type: {
      type: String,
      enum: ['challenges_solved', 'points_earned', 'category_mastery', 'streak', 'special']
    },
    value: Number,
    category: String,
    difficulty: String
  },
  rarity: {
    type: String,
    enum: ['common', 'uncommon', 'rare', 'epic', 'legendary'],
    default: 'common'
  },
  isSecret: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, { timestamps: true });

module.exports = mongoose.model('Badge', badgeSchema);
