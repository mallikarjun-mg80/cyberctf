const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { authenticate, authorize } = require('../middleware/auth');

router.get('/dashboard', authenticate, userController.getDashboard);
router.get('/submissions', authenticate, userController.getUserSubmissions);
router.get('/notifications', authenticate, userController.getNotifications);
router.put('/notifications/:id/read', authenticate, userController.markNotificationRead);
router.get('/:username', userController.getUserProfile);

// Admin routes
router.get('/', authenticate, authorize('admin'), userController.getAllUsers);
router.put('/:id/role', authenticate, authorize('admin'), userController.updateUserRole);

module.exports = router;
