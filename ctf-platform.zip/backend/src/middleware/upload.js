const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const logger = require('../utils/logger');

// Storage configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = req.uploadPath || './uploads/challenges';
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = crypto.randomBytes(16).toString('hex');
    const ext = path.extname(file.originalname);
    cb(null, `${uniqueSuffix}${ext}`);
  }
});

// File filter
const fileFilter = (allowedTypes) => {
  return (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const mimeType = file.mimetype;

    // Check extension
    if (allowedTypes.extensions && !allowedTypes.extensions.includes(ext)) {
      return cb(new Error(`File type ${ext} not allowed`), false);
    }

    // Check MIME type
    if (allowedTypes.mimetypes && !allowedTypes.mimetypes.includes(mimeType)) {
      return cb(new Error(`MIME type ${mimeType} not allowed`), false);
    }

    cb(null, true);
  };
};

// Challenge file upload (pcap, images, binaries)
const challengeUpload = multer({
  storage,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB
    files: 5
  },
  fileFilter: fileFilter({
    extensions: ['.pcap', '.pcapng', '.png', '.jpg', '.jpeg', '.gif', '.zip', '.tar.gz', '.exe', '.elf', '.bin', '.txt', '.pdf'],
    mimetypes: ['application/octet-stream', 'image/*', 'application/zip', 'application/x-gzip', 'text/plain', 'application/pdf']
  })
});

// Avatar upload
const avatarUpload = multer({
  storage: multer.diskStorage({
    destination: './uploads/avatars',
    filename: (req, file, cb) => {
      const uniqueSuffix = crypto.randomBytes(8).toString('hex');
      cb(null, `avatar-${req.user.id}-${uniqueSuffix}${path.extname(file.originalname)}`);
    }
  }),
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB
  },
  fileFilter: fileFilter({
    extensions: ['.png', '.jpg', '.jpeg', '.gif'],
    mimetypes: ['image/png', 'image/jpeg', 'image/gif']
  })
});

// Error handler for multer
const handleUploadError = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        success: false,
        message: 'File too large'
      });
    }
    if (err.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({
        success: false,
        message: 'Too many files'
      });
    }
    return res.status(400).json({
      success: false,
      message: err.message
    });
  }

  if (err) {
    logger.error('Upload error:', err);
    return res.status(400).json({
      success: false,
      message: err.message
    });
  }

  next();
};

module.exports = {
  challengeUpload,
  avatarUpload,
  handleUploadError
};
