const mongoose = require('mongoose');

const teamSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  tag: {
    type: String,
    required: true,
    unique: true,
    uppercase: true,
    maxlength: 5
  },
  description: {
    type: String,
    maxlength: 500
  },
  avatar: {
    type: String,
    default: 'default-team.png'
  },
  captain: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  members: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    role: { type: String, enum: ['member', 'co-captain'], default: 'member' },
    joinedAt: { type: Date, default: Date.now }
  }],
  stats: {
    totalPoints: { type: Number, default: 0 },
    challengesSolved: { type: Number, default: 0 },
    rank: { type: Number, default: 0 }
  },
  inviteCode: {
    type: String,
    unique: true
  },
  isPublic: {
    type: Boolean,
    default: true
  },
  maxMembers: {
    type: Number,
    default: 5
  }
}, { timestamps: true });

module.exports = mongoose.model('Team', teamSchema);
