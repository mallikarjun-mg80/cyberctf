const express = require('express');
const router = express.Router();
const leaderboardController = require('../controllers/leaderboardController');
const { authenticate, optionalAuth } = require('../middleware/auth');

router.get('/', leaderboardController.getLeaderboard);
router.get('/rank', authenticate, leaderboardController.getUserRank);
router.get('/category/:category', leaderboardController.getCategoryLeaderboard);

module.exports = router;
