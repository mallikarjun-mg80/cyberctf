const mongoose = require('mongoose');

const submissionSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  challenge: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Challenge',
    required: true,
    index: true
  },
  flag: {
    type: String,
    required: true,
    select: false
  },
  isCorrect: {
    type: Boolean,
    required: true
  },
  pointsEarned: {
    type: Number,
    default: 0
  },
  attemptNumber: {
    type: Number,
    required: true
  },
  timeTaken: {
    type: Number, // in seconds
    default: 0
  },
  ipAddress: String,
  userAgent: String,
  hintsUsed: [{
    hintIndex: Number,
    usedAt: { type: Date, default: Date.now }
  }],
  source: {
    type: String,
    enum: ['web', 'api', 'cli'],
    default: 'web'
  }
}, {
  timestamps: true
});

// Compound indexes for efficient queries
submissionSchema.index({ user: 1, challenge: 1 });
submissionSchema.index({ user: 1, createdAt: -1 });
submissionSchema.index({ challenge: 1, isCorrect: 1 });

// Static method to get user's attempt count
submissionSchema.statics.getAttemptCount = async function(userId, challengeId) {
  return this.countDocuments({ user: userId, challenge: challengeId });
};

// Static method to check if user solved challenge
submissionSchema.statics.hasSolved = async function(userId, challengeId) {
  const submission = await this.findOne({
    user: userId,
    challenge: challengeId,
    isCorrect: true
  });
  return !!submission;
};

module.exports = mongoose.model('Submission', submissionSchema);
