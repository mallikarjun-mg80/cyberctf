# Deployment Guide

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Local Development](#local-development)
3. [Docker Deployment](#docker-deployment)
4. [Production Deployment](#production-deployment)
5. [SSL/TLS Setup](#ssltls-setup)
6. [Database Migration](#database-migration)
7. [Backup Strategy](#backup-strategy)
8. [Monitoring](#monitoring)
9. [Troubleshooting](#troubleshooting)

## Prerequisites

### Required Software
- Docker Engine 24.0+
- Docker Compose 2.20+
- Git
- Node.js 18+ (for local dev)
- npm 9+ (for local dev)

### System Requirements
- **Minimum**: 2 CPU cores, 4GB RAM, 20GB storage
- **Recommended**: 4 CPU cores, 8GB RAM, 50GB storage
- **Production**: 4+ CPU cores, 16GB+ RAM, 100GB+ SSD storage

## Local Development

### 1. Clone Repository
```bash
git clone <repository-url>
cd ctf-platform
```

### 2. Environment Setup
```bash
# Backend
cd backend
cp .env.example .env
# Edit .env with your values

# Frontend
cd ../frontend
cp .env.example .env
# Edit .env with your values
```

### 3. Start Services
```bash
# Using Docker Compose (Recommended)
docker-compose up -d

# Or manually
docker run -d -p 27017:27017 --name mongodb mongo:7.0
docker run -d -p 6379:6379 --name redis redis:7-alpine

# Backend
cd backend
npm install
npm run dev

# Frontend (new terminal)
cd frontend
npm install
npm run dev
```

### 4. Seed Database
```bash
cd backend
npm run seed
```

### 5. Access Application
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000
- API Docs: http://localhost:5000/api-docs

## Docker Deployment

### Quick Start
```bash
# Build and start all services
docker-compose up -d --build

# View logs
docker-compose logs -f

# Scale backend instances
docker-compose up -d --scale backend=3
```

### Environment Variables
Create `.env` file in project root:

```env
# Database
MONGO_ROOT_USER=admin
MONGO_ROOT_PASS=secure_password_here

# JWT (generate strong random strings)
JWT_SECRET=your-super-secret-jwt-key-min-32-characters-long
JWT_REFRESH_SECRET=your-refresh-secret-key-min-32-characters-long

# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password

# Frontend
FRONTEND_URL=https://your-domain.com

# Optional
SENTRY_DSN=https://xxx@yyy.ingest.sentry.io/zzz
```

### Production Docker Compose
For production, create `docker-compose.prod.yml`:

```yaml
version: '3.8'

services:
  mongodb:
    image: mongo:7.0
    restart: always
    environment:
      MONGO_INITDB_ROOT_USERNAME: ${MONGO_ROOT_USER}
      MONGO_INITDB_ROOT_PASSWORD: ${MONGO_ROOT_PASS}
    volumes:
      - mongodb_data:/data/db
      - ./backups:/backups
    networks:
      - ctf-network
    command: ["mongod", "--auth", "--bind_ip_all"]

  redis:
    image: redis:7-alpine
    restart: always
    command: redis-server --requirepass ${REDIS_PASSWORD}
    volumes:
      - redis_data:/data
    networks:
      - ctf-network

  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    restart: always
    environment:
      NODE_ENV: production
      MONGODB_URI: mongodb://${MONGO_ROOT_USER}:${MONGO_ROOT_PASS}@mongodb:27017/ctf_platform?authSource=admin
      REDIS_URL: redis://:${REDIS_PASSWORD}@redis:6379
      JWT_SECRET: ${JWT_SECRET}
      JWT_REFRESH_SECRET: ${JWT_REFRESH_SECRET}
    depends_on:
      - mongodb
      - redis
    networks:
      - ctf-network
    deploy:
      replicas: 2
      resources:
        limits:
          cpus: '1.0'
          memory: 512M

  nginx:
    image: nginx:alpine
    restart: always
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/ssl:/etc/nginx/ssl:ro
      - frontend_dist:/usr/share/nginx/html:ro
    depends_on:
      - backend
    networks:
      - ctf-network

volumes:
  mongodb_data:
  redis_data:
  frontend_dist:

networks:
  ctf-network:
    driver: bridge
```

## Production Deployment

### AWS Deployment

#### 1. Infrastructure Setup
```bash
# Using Terraform (recommended)
cd terraform/aws
terraform init
terraform plan
terraform apply
```

#### 2. EC2 Instance Setup
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Clone and deploy
git clone <repository-url>
cd ctf-platform
docker-compose -f docker-compose.prod.yml up -d
```

#### 3. Configure Security Group
- Port 80 (HTTP)
- Port 443 (HTTPS)
- Port 22 (SSH) - restrict to your IP
- Port 27017 (MongoDB) - internal only
- Port 6379 (Redis) - internal only

### Google Cloud Platform

#### 1. Create VM Instance
```bash
gcloud compute instances create ctf-platform \
  --machine-type=e2-medium \
  --image-family=ubuntu-2204-lts \
  --image-project=ubuntu-os-cloud \
  --tags=http-server,https-server
```

#### 2. Deploy
```bash
gcloud compute ssh ctf-platform
# Follow same steps as AWS EC2 setup
```

### Azure Deployment

#### 1. Create VM
```bash
az vm create \
  --resource-group ctf-rg \
  --name ctf-platform \
  --image Ubuntu2204 \
  --size Standard_B2s \
  --generate-ssh-keys
```

## SSL/TLS Setup

### Using Let's Encrypt
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Auto-renewal
sudo certbot renew --dry-run
```

### Manual SSL Certificate
```bash
# Generate private key
openssl genrsa -out private.key 2048

# Generate CSR
openssl req -new -key private.key -out certificate.csr

# Generate self-signed certificate (dev only)
openssl x509 -req -days 365 -in certificate.csr -signkey private.key -out certificate.crt
```

## Database Migration

### Backup
```bash
# Docker
docker-compose exec mongodb mongodump --out /backups/$(date +%Y%m%d)

# Local
mongodump --uri="mongodb://localhost:27017/ctf_platform" --out ./backups
```

### Restore
```bash
# Docker
docker-compose exec mongodb mongorestore /backups/20240101/ctf_platform

# Local
mongorestore --uri="mongodb://localhost:27017/ctf_platform" ./backups/ctf_platform
```

## Backup Strategy

### Automated Backups
```bash
# Add to crontab
crontab -e

# Daily backup at 2 AM
0 2 * * * cd /path/to/ctf-platform && docker-compose exec -T mongodb mongodump --out /backups/$(date +\%Y\%m\%d) >> /var/log/ctf-backup.log 2>&1

# Weekly cleanup (keep last 30 days)
0 3 * * 0 find /path/to/backups -type d -mtime +30 -exec rm -rf {} +
```

### Backup Script
```bash
#!/bin/bash
# backup.sh

BACKUP_DIR="/backups/$(date +%Y%m%d_%H%M%S)"
mkdir -p $BACKUP_DIR

# Database
docker-compose exec -T mongodb mongodump --out $BACKUP_DIR/db

# Uploads
cp -r ./backend/uploads $BACKUP_DIR/uploads

# Compress
tar -czf $BACKUP_DIR.tar.gz $BACKUP_DIR
rm -rf $BACKUP_DIR

# Upload to S3 (optional)
aws s3 cp $BACKUP_DIR.tar.gz s3://your-bucket/backups/

echo "Backup completed: $BACKUP_DIR.tar.gz"
```

## Monitoring

### Health Checks
```bash
# Application health
curl http://localhost:5000/health

# Database health
curl http://localhost:5000/health/db

# Redis health
curl http://localhost:5000/health/redis
```

### Log Aggregation
```bash
# View all logs
docker-compose logs -f

# View specific service
docker-compose logs -f backend

# View error logs
docker-compose logs backend | grep ERROR
```

### Prometheus Metrics (Optional)
Add to `docker-compose.yml`:
```yaml
  prometheus:
    image: prom/prometheus
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
    ports:
      - "9090:9090"

  grafana:
    image: grafana/grafana
    ports:
      - "3001:3000"
```

## Troubleshooting

### Common Issues

#### MongoDB Connection Refused
```bash
# Check if MongoDB is running
docker-compose ps mongodb

# Check logs
docker-compose logs mongodb

# Reset MongoDB
docker-compose restart mongodb
```

#### Redis Connection Error
```bash
# Check Redis
docker-compose exec redis redis-cli ping

# Restart Redis
docker-compose restart redis
```

#### Port Already in Use
```bash
# Find process using port
sudo lsof -i :5000

# Kill process
sudo kill -9 <PID>

# Or change port in docker-compose.yml
```

#### Permission Denied (File Uploads)
```bash
# Fix permissions
sudo chown -R 1001:1001 ./backend/uploads

# Or run as current user
docker-compose exec backend chown -R nodejs:nodejs /app/uploads
```

#### JWT Secret Not Set
```bash
# Generate secure secret
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"

# Add to .env
JWT_SECRET=<generated-secret>
```

### Performance Tuning

#### MongoDB
```javascript
// Add indexes
db.challenges.createIndex({ category: 1, difficulty: 1 });
db.submissions.createIndex({ user: 1, challenge: 1 });
db.users.createIndex({ "stats.totalPoints": -1 });
```

#### Nginx
```nginx
# /etc/nginx/nginx.conf
worker_processes auto;
worker_connections 4096;

gzip on;
gzip_types text/plain text/css application/json application/javascript;

client_body_buffer_size 10K;
client_header_buffer_size 1k;
client_max_body_size 50m;
```

#### Node.js
```javascript
// server.js
const cluster = require('cluster');
const os = require('os');

if (cluster.isMaster) {
  const numCPUs = os.cpus().length;
  for (let i = 0; i < numCPUs; i++) {
    cluster.fork();
  }
} else {
  // Start server
}
```

## Security Checklist

- [ ] Change default passwords
- [ ] Enable MongoDB authentication
- [ ] Set strong JWT secrets
- [ ] Configure CORS properly
- [ ] Enable rate limiting
- [ ] Set up SSL/TLS
- [ ] Configure firewall rules
- [ ] Enable audit logging
- [ ] Set up automated backups
- [ ] Regular security updates
- [ ] Container image scanning
- [ ] Secrets management (not in code)
- [ ] Network segmentation
- [ ] DDoS protection (CloudFlare/AWS Shield)
- [ ] Intrusion detection

## Support

For issues and feature requests, please open an issue on GitHub.

For security vulnerabilities, please email security@ctfplatform.com.
