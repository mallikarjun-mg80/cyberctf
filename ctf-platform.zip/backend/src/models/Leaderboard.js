const mongoose = require('mongoose');

const leaderboardSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: ['global', 'weekly', 'monthly', 'category', 'event'],
    required: true
  },
  period: {
    start: Date,
    end: Date
  },
  category: String, // For category-specific leaderboards
  entries: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    username: String,
    points: Number,
    challengesSolved: Number,
    rank: Number,
    lastUpdated: { type: Date, default: Date.now }
  }],
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

leaderboardSchema.index({ type: 1, 'period.start': -1 });

module.exports = mongoose.model('Leaderboard', leaderboardSchema);
