#!/bin/bash
# CTF Platform - One-Click Deploy Script
# Works on: Ubuntu 22.04+, Debian 11+, any Docker-capable VPS

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║           CTF Platform - One-Click Deployer                  ║"
echo "║     Cybersecurity Learning Environment - Production Ready    ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}❌ Please run as root or with sudo${NC}"
    exit 1
fi

# Detect OS
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$NAME
else
    echo -e "${RED}❌ Cannot detect OS${NC}"
    exit 1
fi

echo -e "${BLUE}📋 Detected OS: $OS${NC}"

# Install Docker if not present
if ! command -v docker &> /dev/null; then
    echo -e "${YELLOW}🐳 Docker not found. Installing...${NC}"
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    usermod -aG docker $SUDO_USER || true
    rm get-docker.sh
    systemctl enable docker
    systemctl start docker
    echo -e "${GREEN}✅ Docker installed${NC}"
else
    echo -e "${GREEN}✅ Docker already installed${NC}"
fi

# Install Docker Compose if not present
if ! command -v docker-compose &> /dev/null; then
    echo -e "${YELLOW}🐳 Docker Compose not found. Installing...${NC}"
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    echo -e "${GREEN}✅ Docker Compose installed${NC}"
else
    echo -e "${GREEN}✅ Docker Compose already installed${NC}"
fi

# Create app directory
APP_DIR="/opt/ctf-platform"
mkdir -p $APP_DIR
cd $APP_DIR

echo -e "${BLUE}📁 Working directory: $APP_DIR${NC}"

# Check if project files exist
if [ ! -f "docker-compose.yml" ]; then
    echo -e "${YELLOW}📥 Project files not found. Please extract the ctf-platform.zip here first.${NC}"
    echo -e "${YELLOW}   Or clone from: git clone <your-repo-url>${NC}"
    exit 1
fi

# Generate secure secrets
echo -e "${BLUE}🔐 Generating secure secrets...${NC}"
JWT_SECRET=$(openssl rand -hex 64)
JWT_REFRESH_SECRET=$(openssl rand -hex 64)
MONGO_ROOT_PASS=$(openssl rand -hex 32)
REDIS_PASS=$(openssl rand -hex 32)

# Create .env file
cat > .env <<EOF
# Database
MONGO_ROOT_USER=admin
MONGO_ROOT_PASS=$MONGO_ROOT_PASS

# JWT Secrets
JWT_SECRET=$JWT_SECRET
JWT_REFRESH_SECRET=$JWT_REFRESH_SECRET

# Redis
REDIS_PASSWORD=$REDIS_PASS

# Email (configure these)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password

# Frontend URL (update with your domain)
FRONTEND_URL=http://$(curl -s ifconfig.me || echo "localhost")

# Optional: Sentry
# SENTRY_DSN=
EOF

echo -e "${GREEN}✅ Environment file created${NC}"

# Create required directories
mkdir -p backend/uploads/challenges
mkdir -p backend/uploads/avatars
mkdir -p backend/logs
mkdir -p docker

echo -e "${BLUE}🚀 Starting services...${NC}"
docker-compose down 2>/dev/null || true
docker-compose pull
docker-compose up -d --build

# Wait for services to be healthy
echo -e "${YELLOW}⏳ Waiting for services to start...${NC}"
sleep 10

# Check health
echo -e "${BLUE}🔍 Checking service health...${NC}"
if docker-compose ps | grep -q "Up"; then
    echo -e "${GREEN}✅ Services are running${NC}"
else
    echo -e "${RED}❌ Some services failed to start${NC}"
    docker-compose logs
    exit 1
fi

# Seed database
echo -e "${BLUE}🌱 Seeding database with 87 challenges...${NC}"
docker-compose exec -T backend node src/utils/seed.js || echo -e "${YELLOW}⚠️  Seeding may have already been done${NC}"

# Get IP
SERVER_IP=$(curl -s ifconfig.me || echo "localhost")

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║              🎉 DEPLOYMENT SUCCESSFUL! 🎉                   ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}🌐 Access your CTF Platform:${NC}"
echo -e "   Frontend: ${GREEN}http://$SERVER_IP${NC}"
echo -e "   API:      ${GREEN}http://$SERVER_IP:5000${NC}"
echo -e "   Health:   ${GREEN}http://$SERVER_IP:5000/health${NC}"
echo ""
echo -e "${BLUE}📊 Services:${NC}"
docker-compose ps

echo ""
echo -e "${YELLOW}⚠️  IMPORTANT NEXT STEPS:${NC}"
echo -e "   1. ${YELLOW}Configure your domain${NC} and update FRONTEND_URL in .env"
echo -e "   2. ${YELLOW}Set up SSL${NC} with: certbot --nginx -d yourdomain.com"
echo -e "   3. ${YELLOW}Configure email${NC} SMTP settings in .env"
echo -e "   4. ${YELLOW}Change default passwords${NC} in .env"
echo -e "   5. ${YELLOW}Set up backups${NC}: crontab -e and add backup script"
echo ""
echo -e "${BLUE}🛠️  Useful Commands:${NC}"
echo -e "   View logs:     ${GREEN}docker-compose logs -f${NC}"
echo -e "   Stop:          ${GREEN}docker-compose down${NC}"
echo -e "   Restart:       ${GREEN}docker-compose restart${NC}"
echo -e "   Update:        ${GREEN}docker-compose pull && docker-compose up -d${NC}"
echo -e "   Backup DB:     ${GREEN}docker-compose exec mongodb mongodump --out /backups/$(date +%Y%m%d)${NC}"
echo ""
echo -e "${GREEN}✨ Your CTF Platform is ready! Happy hacking! ✨${NC}"
