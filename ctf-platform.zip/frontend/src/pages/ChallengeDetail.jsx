import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';
import { 
  Trophy, 
  Clock, 
  Lock, 
  Unlock, 
  Lightbulb, 
  Send, 
  CheckCircle, 
  XCircle,
  ArrowLeft,
  FileText,
  Terminal,
  Download,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Star
} from 'lucide-react';
import { toast } from 'react-hot-toast';

const difficultyColors = {
  'Easy': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  'Medium': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  'Hard': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  'Insane': 'bg-red-500/20 text-red-400 border-red-500/30'
};

const ChallengeDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const queryClient = useQueryClient();
  const [flag, setFlag] = useState('');
  const [showHints, setShowHints] = useState(false);
  const [expandedHint, setExpandedHint] = useState(null);

  const { data, isLoading } = useQuery({
    queryKey: ['challenge', id],
    queryFn: async () => {
      const response = await axios.get(`/api/challenges/${id}`);
      return response.data;
    }
  });

  const submitMutation = useMutation({
    mutationFn: async (flagValue) => {
      const response = await axios.post(`/api/challenges/${id}/submit`, { flag: flagValue });
      return response.data;
    },
    onSuccess: (data) => {
      if (data.data.correct) {
        toast.success(data.data.message);
        queryClient.invalidateQueries(['challenge', id]);
        queryClient.invalidateQueries(['challenges']);
        queryClient.invalidateQueries(['dashboard']);
      } else {
        toast.error(data.data.message);
      }
      setFlag('');
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || 'Failed to submit flag');
    }
  });

  const hintMutation = useMutation({
    mutationFn: async (hintIndex) => {
      const response = await axios.post(`/api/challenges/${id}/hints/${hintIndex}`);
      return response.data;
    },
    onSuccess: (data) => {
      toast.success(`Hint revealed! Cost: ${data.data.cost} points`);
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || 'Failed to get hint');
    }
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-400" />
      </div>
    );
  }

  const { challenge, userProgress, isSolved } = data?.data || {};

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!flag.trim()) return;
    submitMutation.mutate(flag.trim());
  };

  const handleHint = (index) => {
    if (!isAuthenticated) {
      toast.error('Please login to view hints');
      return;
    }
    hintMutation.mutate(index);
    setExpandedHint(expandedHint === index ? null : index);
  };

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <button
          onClick={() => navigate('/challenges')}
          className="flex items-center gap-2 text-slate-400 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Challenges</span>
        </button>

        {/* Challenge Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-3xl md:text-4xl font-bold text-white">
                  {challenge?.title}
                </h1>
                {isSolved && (
                  <div className="flex items-center gap-1 px-3 py-1 bg-emerald-500/20 text-emerald-400 rounded-full text-sm font-medium">
                    <CheckCircle className="w-4 h-4" />
                    Solved
                  </div>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <span className={`px-3 py-1 rounded-full text-sm font-medium border ${difficultyColors[challenge?.difficulty]}`}>
                  {challenge?.difficulty}
                </span>
                <span className="flex items-center gap-1 text-slate-400 text-sm">
                  <Trophy className="w-4 h-4" />
                  {challenge?.points} points
                </span>
                <span className="flex items-center gap-1 text-slate-400 text-sm">
                  <Star className="w-4 h-4" />
                  {challenge?.category}
                </span>
                <span className="flex items-center gap-1 text-slate-400 text-sm">
                  <Terminal className="w-4 h-4" />
                  {challenge?.challengeType}
                </span>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Description */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800"
            >
              <h2 className="text-xl font-semibold text-white mb-4">Description</h2>
              <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">
                {challenge?.description}
              </p>
            </motion.div>

            {/* Attachments */}
            {challenge?.attachments && challenge.attachments.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800"
              >
                <h2 className="text-xl font-semibold text-white mb-4">Attachments</h2>
                <div className="space-y-2">
                  {challenge.attachments.map((file, index) => (
                    <a
                      key={index}
                      href={`/uploads/challenges/${file.filename}`}
                      download
                      className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors group"
                    >
                      <Download className="w-5 h-5 text-emerald-400 group-hover:text-emerald-300" />
                      <div>
                        <p className="text-white text-sm">{file.originalName || file.filename}</p>
                        <p className="text-slate-500 text-xs">{file.description}</p>
                      </div>
                    </a>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Learning Objectives */}
            {challenge?.learningObjectives && challenge.learningObjectives.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800"
              >
                <h2 className="text-xl font-semibold text-white mb-4">Learning Objectives</h2>
                <ul className="space-y-2">
                  {challenge.learningObjectives.map((objective, index) => (
                    <li key={index} className="flex items-start gap-2 text-slate-300">
                      <CheckCircle className="w-5 h-5 text-emerald-400 mt-0.5 shrink-0" />
                      <span>{objective}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            )}

            {/* Resources */}
            {challenge?.resources && challenge.resources.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800"
              >
                <h2 className="text-xl font-semibold text-white mb-4">Resources</h2>
                <div className="space-y-2">
                  {challenge.resources.map((resource, index) => (
                    <a
                      key={index}
                      href={resource.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors group"
                    >
                      <FileText className="w-5 h-5 text-blue-400" />
                      <div>
                        <p className="text-white text-sm group-hover:text-blue-400 transition-colors">
                          {resource.title}
                        </p>
                        <p className="text-slate-500 text-xs">{resource.type}</p>
                      </div>
                    </a>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Flag Submission */}
            {!isSolved && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800"
              >
                <h2 className="text-xl font-semibold text-white mb-4">Submit Flag</h2>

                {!isAuthenticated ? (
                  <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                    <p className="text-slate-400 text-center">
                      Please <a href="/login" className="text-emerald-400 hover:underline">login</a> to submit flags
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="flex gap-3">
                      <div className="flex-1 relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                        <input
                          type="text"
                          value={flag}
                          onChange={(e) => setFlag(e.target.value)}
                          placeholder={`Enter flag (format: ${challenge?.flagFormat || 'CTF{...}'})`}
                          className="w-full pl-10 pr-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 font-mono"
                        />
                      </div>
                      <button
                        type="submit"
                        disabled={submitMutation.isPending || !flag.trim()}
                        className="flex items-center gap-2 px-6 py-3 bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-700 disabled:text-slate-500 text-white rounded-xl font-semibold transition-all"
                      >
                        <Send className="w-4 h-4" />
                        {submitMutation.isPending ? 'Submitting...' : 'Submit'}
                      </button>
                    </div>

                    {userProgress && (
                      <div className="flex items-center gap-2 text-sm text-slate-500">
                        <AlertTriangle className="w-4 h-4" />
                        <span>Attempt {userProgress.attempts + 1}</span>
                      </div>
                    )}
                  </form>
                )}
              </motion.div>
            )}

            {/* Solved State */}
            {isSolved && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-6 rounded-2xl bg-emerald-500/10 border border-emerald-500/30"
              >
                <div className="flex items-center gap-3 mb-2">
                  <CheckCircle className="w-8 h-8 text-emerald-400" />
                  <h2 className="text-xl font-semibold text-emerald-400">Challenge Solved!</h2>
                </div>
                <p className="text-slate-300">
                  Congratulations! You have successfully solved this challenge.
                  {userProgress?.pointsEarned && ` You earned ${userProgress.pointsEarned} points.`}
                </p>
              </motion.div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Challenge Stats */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800"
            >
              <h3 className="text-lg font-semibold text-white mb-4">Statistics</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Solves</span>
                  <span className="text-white font-medium">{challenge?.solveCount || 0}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Success Rate</span>
                  <span className="text-white font-medium">
                    {challenge?.successRate ? `${challenge.successRate.toFixed(1)}%` : 'N/A'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Type</span>
                  <span className="text-white font-medium capitalize">
                    {challenge?.challengeType?.replace('_', ' ')}
                  </span>
                </div>
              </div>
            </motion.div>

            {/* Hints */}
            {challenge?.hints && challenge.hints.length > 0 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800"
              >
                <button
                  onClick={() => setShowHints(!showHints)}
                  className="flex items-center justify-between w-full mb-4"
                >
                  <div className="flex items-center gap-2">
                    <Lightbulb className="w-5 h-5 text-yellow-400" />
                    <h3 className="text-lg font-semibold text-white">Hints</h3>
                  </div>
                  {showHints ? <ChevronUp className="w-5 h-5 text-slate-400" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
                </button>

                <AnimatePresence>
                  {showHints && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="space-y-2 overflow-hidden"
                    >
                      {challenge.hints.map((hint, index) => (
                        <div key={index} className="border border-slate-800 rounded-xl overflow-hidden">
                          <button
                            onClick={() => handleHint(index)}
                            className="w-full flex items-center justify-between p-3 bg-slate-800/50 hover:bg-slate-800 transition-colors"
                          >
                            <span className="text-sm text-slate-300">Hint {index + 1}</span>
                            <span className="text-xs text-yellow-400">
                              {hint.cost > 0 ? `-${hint.cost} pts` : 'Free'}
                            </span>
                          </button>
                          <AnimatePresence>
                            {expandedHint === index && (
                              <motion.div
                                initial={{ height: 0 }}
                                animate={{ height: 'auto' }}
                                exit={{ height: 0 }}
                                className="p-3 text-slate-300 text-sm bg-slate-800/30"
                              >
                                {hint.content}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}

            {/* Tags */}
            {challenge?.tags && challenge.tags.length > 0 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
                className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800"
              >
                <h3 className="text-lg font-semibold text-white mb-4">Tags</h3>
                <div className="flex flex-wrap gap-2">
                  {challenge.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 bg-slate-800 text-slate-400 rounded-full text-sm"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChallengeDetail;
